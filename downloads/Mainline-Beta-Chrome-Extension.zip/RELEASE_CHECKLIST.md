# Release Checklist

For online testing:
- Use Chrome Web Store Private or Unlisted release.
- Required permission explanations:
  - storage: saves the user's mainline data.
  - sidePanel: displays Mainline as a right-side Chrome panel.
  - tabs/windows: opens or closes the side panel across Chrome windows.
- Prepare screenshots showing the side panel next to a normal webpage.
- Prepare privacy policy.
