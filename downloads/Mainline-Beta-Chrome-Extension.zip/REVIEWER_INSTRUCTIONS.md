# Chrome Web Store Reviewer Instructions

Mainline does not require an account or login.

1. Install the extension.
2. Click the Mainline toolbar icon to open Chrome's side panel.
3. Use the Mainline panel from the side panel.
4. Open a mainline folder and add or edit a todo.
5. Open Calendar to navigate to another date or enable `Show details`.
6. Open Note to verify that notes are stored separately by date.
7. Close the side panel when finished.

Permission notes:

- `storage` is used only for local user-created content and preferences.
- `sidePanel` is used to open Mainline in Chrome's built-in side panel.
- Mainline does not request broad host permissions or inject content scripts
  into webpages.

No user content or webpage content is transmitted to an external server.
