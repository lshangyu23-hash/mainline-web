chrome.runtime.onInstalled.addListener(() => {
  if (!chrome.sidePanel?.setPanelBehavior) return;
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
    // Older Chrome versions may not support this helper.
  });
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!chrome.sidePanel?.open) return;
  try {
    await chrome.sidePanel.open({ windowId: tab.windowId });
  } catch {
    // The side panel can only be opened from a direct user gesture.
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "MAINLINE_OPEN_LINK") return false;
  if (!/^https?:\/\//.test(message.url || "")) return false;

  chrome.tabs.create({ url: message.url });
  return false;
});
