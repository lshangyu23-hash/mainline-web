# Mainline - Life Tracker | User Test v1.17

## Install

1. Download and unzip the folder.
2. Open Chrome.
3. Go to `chrome://extensions`.
4. Turn on **Developer mode**.
5. Click **Load unpacked**.
6. Select `Mainline-Life-Tracker-User-Test-v1-17`.
7. Pin the Mainline icon.
8. Open a normal webpage and click the Mainline icon.

## What to test first

- Look at the Today section.
- Confirm folder titles are no longer forced into a fixed-width column.
- Confirm the checkbox visually aligns with the first line of its corresponding item.
- Confirm the row feels natural and not overly columnized.
- Confirm the delete `×` still only appears near the far right hover area.
