# First Publish Checklist

## Package

- [x] Manifest V3
- [x] Version set to `1.0.0`
- [x] Demo wording removed from manifest
- [x] Unused `activeTab` and `tabs` permissions removed
- [x] Upload ZIP has `manifest.json` at its root
- [x] No remote code, analytics, ads, or external data transmission

## Chrome Web Store Dashboard

- [ ] Register and verify the Chrome Web Store developer account
- [ ] Upload the release ZIP
- [ ] Paste the listing copy from `STORE_LISTING.md`
- [ ] Declare the extension's single purpose
- [ ] Add the permission justifications
- [ ] Declare local handling of user-created content
- [ ] Add reviewer instructions from `REVIEWER_INSTRUCTIONS.md`
- [ ] Choose Unlisted visibility for the first colleague/friend test

## Required Before Submission

- [ ] Replace `[YOUR SUPPORT EMAIL]` in `PRIVACY_POLICY.md`
- [ ] Host the privacy policy at a public URL
- [ ] Add the privacy policy URL in the dashboard
- [ ] Add a support email in the dashboard
- [x] Capture store screenshots
- [ ] Test the final ZIP as an unpacked extension in a clean Chrome profile

## Suggested First Release

Use an **Unlisted** release first. Share the store link with colleagues and
friends, collect feedback, then switch to Public after the first stability
round.
