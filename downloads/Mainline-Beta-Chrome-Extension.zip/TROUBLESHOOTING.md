# Mainline Troubleshooting

## I cannot load it in Chrome

Make sure you are selecting the unzipped folder, not the `.zip` file.

Correct folder:
`Mainline-Life-Tracker-Demo-v1-Stable`

## I loaded it, but I do not see it

1. Open a normal webpage.
2. Click the Mainline toolbar icon.
3. It will not show on Chrome New Tab, `chrome://extensions`, Chrome settings, or Chrome Web Store pages.

## The icon is not visible

Click the puzzle-piece Extensions icon in Chrome, then pin Mainline.

## I updated the extension but nothing changed

1. Go to `chrome://extensions`.
2. Remove the old Mainline extension.
3. Load the new unzipped folder again.
4. Open a normal webpage and click the Mainline icon.
