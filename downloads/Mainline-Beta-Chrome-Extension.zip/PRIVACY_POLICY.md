# Mainline Privacy Policy

Effective date: June 11, 2026

Mainline is a personal life tracker that appears in Chrome's built-in side
panel.

## Data Mainline Stores

Mainline stores content that the user creates, including:

- Mainline folder names
- Todos, deadlines, and completion history
- Calendar special days
- Daily notes
- Profile names and layout preferences

This information is stored locally using Chrome extension storage in the
user's Chrome profile.

## Data Mainline Does Not Collect

Mainline does not sell user data, display advertising, use analytics, collect
browsing history, read webpage content for tracking, or transmit user-created
content to external servers.

## Permissions

- `storage` saves the user's Mainline content and preferences locally.
- `sidePanel` lets the user open Mainline in Chrome's built-in side panel.

Mainline does not request broad website access in this version.

## Data Sharing and Retention

Mainline does not share user data with third parties. Data remains in Chrome
extension storage until the user deletes it, deletes a profile or item, clears
extension storage, or uninstalls the extension.

## Future Changes

If a future version adds account sync, cloud storage, analytics, or AI
features, this policy will be updated before those features are released.

## Contact

Before publishing, replace this line with a support email address:
`[YOUR SUPPORT EMAIL]`
