# Mainline - Life Tracker

Mainline is a side-panel life tracker for Chrome. It keeps important life
mainlines, daily actions, calendar plans, special days, and dated notes within
reach while browsing.

## First Public Beta

- All user-created content is stored locally in Chrome extension storage.
- Mainline does not send user content or browsing data to external servers.
- Click the toolbar icon to open Mainline in Chrome's side panel.
- Mainline does not request broad website access in this version.

See `PRIVACY_POLICY.md`, `STORE_LISTING.md`, and `PUBLISH_CHECKLIST.md` for
Chrome Web Store submission materials.
