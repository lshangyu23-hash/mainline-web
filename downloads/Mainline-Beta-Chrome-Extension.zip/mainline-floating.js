
(async () => {
  const HOST_ID = "mainline-floating-tracker-host";
  const GLOBAL_ENABLED_KEY = "mainline_global_enabled_demo_v1_stable";
  const STORAGE_KEY = "mainline_floating_demo_v1_stable";
  const LAYOUT_KEY = "mainline_layout_settings";
  const CLIENT_ID = crypto.randomUUID();
  const OLD_STORAGE_KEYS = [
    "mainline_floating_user_test_v1_17",
    "mainline_floating_user_test_v1_15",
    "mainline_floating_user_test_v1_16",
    "mainline_floating_user_test_v1_14",
    "mainline_floating_user_test_v1_13",
    "mainline_floating_user_test_v1_12",
    "mainline_floating_user_test_v1_11",
    "mainline_floating_user_test_v1_10",
    "mainline_floating_user_test_v1_9",
    "mainline_floating_user_test_v1_8",
    "mainline_floating_user_test_v1_7",
    "mainline_floating_user_test_v1_5",
    "mainline_floating_user_test_v1_6",
    "mainline_floating_user_test_v1_4",
    "mainline_floating_user_test_v1_2",
    "mainline_floating_user_test_v1_3",
    "mainline_floating_user_test_v1",
    "mainline_floating_user_test_v1_1",
    "mainline_floating_v90",
    "mainline_floating_v89",
    "mainline_floating_v88",
    "mainline_floating_v87",
    "mainline_floating_v86",
    "mainline_floating_v85",
    "mainline_floating_v84",
    "mainline_floating_v83",
    "mainline_floating_v82",
    "mainline_floating_v81",
    "mainline_floating_v80",
    "mainline_floating_v79",
    "mainline_floating_v78",
    "mainline_floating_v77",
    "mainline_floating_v76",
    "mainline_floating_v75",
    "mainline_floating_v74",
    "mainline_floating_v73",
    "mainline_floating_v72",
    "mainline_floating_v71",
    "mainline_floating_v70",
    "mainline_floating_v69",
    "mainline_floating_v68",
    "mainline_floating_v67",
    "mainline_floating_v66",
    "mainline_floating_v65",
    "mainline_floating_v64",
    "mainline_floating_v63",
    "mainline_floating_v62",
    "mainline_floating_v61",
    "mainline_floating_v60",
    "mainline_floating_v59",
    "mainline_floating_v58",
    "mainline_floating_v57",
    "mainline_floating_v56",
    "mainline_floating_v55",
    "mainline_floating_v54",
    "mainline_floating_v53",
    "mainline_floating_v52",
    "mainline_floating_v51",
    "mainline_floating_v50",
    "mainline_floating_v49",
    "mainline_floating_v48",
    "mainline_floating_v47",
    "mainline_floating_v46",
    "mainline_floating_v45",
    "mainline_floating_v44",
    "mainline_floating_v43",
    "mainline_floating_v42",
    "mainline_floating_v41",
    "mainline_floating_v40",
    "mainline_floating_v39",
    "mainline_floating_v38",
    "mainline_floating_v37",
    "mainline_floating_v36",
    "mainline_floating_v35",
    "mainline_floating_v34",
    "mainline_floating_v33",
    "mainline_floating_v32",
    "mainline_floating_v31",
    "mainline_floating_v30",
    "mainline_floating_v29",
    "mainline_floating_v28",
    "mainline_floating_v27",
    "mainline_floating_v26",
    "mainline_floating_v25",
    "mainline_floating_v24",
    "mainline_floating_v23",
    "mainline_floating_v22",
    "mainline_floating_v21",
    "mainline_floating_v20",
    "mainline_floating_v19",
    "mainline_floating_v18",
    "mainline_floating_v17",
    "mainline_floating_v16",
    "mainline_floating_v15",
    "mainline_floating_v14",
    "mainline_floating_v13",
    "mainline_floating_v12",
    "mainline_floating_v11",
    "mainline_floating_v10",
    "mainline_floating_v09"
  ];

  const DEFAULT_COLOR = "#24b51e";
  const DEFAULT_PROFILE_ID = "profile-1";
  const IS_EXTENSION_PAGE = location.protocol === "chrome-extension:";
  const IS_MAINLINE_EMBED = document.documentElement.dataset.mainlineEmbed === "true";

  if (!IS_EXTENSION_PAGE) {
    try {
      const globalState = await chrome.storage.local.get(GLOBAL_ENABLED_KEY);
      if (!globalState[GLOBAL_ENABLED_KEY]) return;
    } catch (error) {
      // If storage is unavailable, do not show the panel.
      return;
    }
  }

  const existing = document.getElementById(HOST_ID);
  if (existing) {
    return;
  }

  const makeCompleted = (text = "", freeType = "") => ({
    id: crypto.randomUUID(),
    text,
    note: freeType,
    freeType,
    doneAt: Date.now()
  });

  function currentProfileId() {
    try {
      return activeProfileId || DEFAULT_PROFILE_ID;
    } catch {
      return DEFAULT_PROFILE_ID;
    }
  }

  const makeTodo = (text = "", keepBlank = false, freeType = "", scheduledFor = todayKey(), deadlineFor = "") => ({
    id: crypto.randomUUID(),
    text,
    freeType,
    keepBlank,
    done: false,
    completedId: null,
    createdFor: scheduledFor || todayKey(),
    scheduledFor: scheduledFor || todayKey(),
    deadlineFor: deadlineFor || "",
    profileId: currentProfileId(),
    createdAt: Date.now()
  });

  const makeCalendarLabel = (date = todayKey(), text = "", kind = "personal", color = "#6f7f9f") => ({
    id: crypto.randomUUID(),
    date,
    text,
    kind,
    color,
    profileId: currentProfileId(),
    createdAt: Date.now()
  });

  const defaultProfiles = [
    { id: DEFAULT_PROFILE_ID, name: "Mainline User 1" },
    { id: "profile-2", name: "Mainline User 2" }
  ];

  const makeSteps = (todayTodos = [], freeType = "", completed = []) => ({
    completed,
    todayTodos,
    freeType
  });

  const defaultMainlines = [
    {
      id: crypto.randomUUID(),
      name: "Make your 1st mainline here",
      steps: makeSteps([
        makeTodo("Move one outcome forward")
      ], "", [
        makeCompleted("Opened Mainline for the first time")
      ]),
      color: DEFAULT_COLOR,
      profileId: DEFAULT_PROFILE_ID,
      trashed: false,
      updatedAt: Date.now()
    },
    {
      id: crypto.randomUUID(),
      name: "Next mainline",
      steps: makeSteps([], "", []),
      color: DEFAULT_COLOR,
      profileId: DEFAULT_PROFILE_ID,
      trashed: false,
      updatedAt: Date.now()
    },
    {
      id: crypto.randomUUID(),
      name: "Make your 1st mainline here",
      steps: makeSteps([
        makeTodo("Move one outcome forward")
      ], "", []),
      color: DEFAULT_COLOR,
      profileId: "profile-2",
      trashed: false,
      updatedAt: Date.now()
    }
  ];

  const host = document.createElement("div");
  host.id = HOST_ID;
  const embedTarget = IS_MAINLINE_EMBED ? document.getElementById("mainline-newtab-panel") : null;
  (embedTarget || document.documentElement).appendChild(host);
  if (IS_EXTENSION_PAGE && !IS_MAINLINE_EMBED) {
    host.style.setProperty("position", "fixed", "important");
    host.style.setProperty("inset", "0", "important");
    host.style.setProperty("width", "100vw", "important");
    host.style.setProperty("min-width", "100vw", "important");
    host.style.setProperty("max-width", "100vw", "important");
    host.style.setProperty("height", "100vh", "important");
  }

  if (IS_MAINLINE_EMBED) {
    host.style.setProperty("position", "relative", "important");
    host.style.setProperty("display", "block", "important");
    host.style.setProperty("width", "100%", "important");
    host.style.setProperty("min-width", "0", "important");
    host.style.setProperty("max-width", "none", "important");
    host.style.setProperty("height", "100vh", "important");
    host.style.setProperty("z-index", "1", "important");
  }

  host.classList.toggle("embedded-host", IS_MAINLINE_EMBED);
  const root = host.attachShadow({ mode: "open" });
  const logoUrl = chrome.runtime.getURL("brand-logo-cropped.png");

  root.innerHTML = `
    <style>
      :host {
        all: initial;
        position: fixed;
        top: 0;
        right: 0;
        width: var(--mainline-panel-width, clamp(260px, 20vw, 420px));
        min-width: 220px;
        max-width: min(720px, 75vw);
        height: 100vh;
        z-index: 2147483647;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
        color: #202124;
        overflow: visible;
      }


      :host(.collapsed-host) {
        width: 20px !important;
        min-width: 20px !important;
        max-width: 20px !important;
      }

      :host(.embedded-host.collapsed-host) {
        width: 100% !important;
        min-width: 0 !important;
        max-width: none !important;
      }

      :host(.collapsed-host) {
        pointer-events: none !important;
      }

      :host(.collapsed-host) .panel.collapsed {
        pointer-events: none !important;
        background: transparent;
        border-left: 0;
        box-shadow: none;
      }

      :host(.collapsed-host) .panel.collapsed .fold-toggle {
        pointer-events: auto !important;
      }


      .panel {
        overflow: visible;
      }

      .fold-toggle {
        z-index: 2147483647;
        width: 22px;
        height: 64px;
        color: #158a18;
        border-color: #d7ead3;
        background: #fffefb;
      }

      * { box-sizing: border-box; }

      .panel {
        position: relative;
        width: 100%;
        height: 100%;
        min-width: 0;
        display: flex;
        flex-direction: column;
        background: #fffefb;
        border-left: 1px solid #efebe3;
        box-shadow: -8px 0 24px rgba(32, 33, 36, 0.08);
        overflow: visible;
        transform: translateX(0);
        transition: transform 180ms ease;
      }

      .panel.collapsed { transform: translateX(100%); }

      .width-resizer {
        position: absolute;
        left: -4px;
        top: 0;
        width: 8px;
        height: 100%;
        cursor: ew-resize;
        z-index: 4;
        background: transparent;
      }

      .width-resizer::after {
        content: "";
        position: absolute;
        left: 3px;
        top: 0;
        bottom: 0;
        width: 1px;
        background: transparent;
      }

      .width-resizer:hover::after,
      .width-resizer.dragging::after {
        background: #cfe8cc;
      }

      .panel.collapsed .width-resizer {
        display: none;
      }

      .fold-toggle {
        position: absolute;
        left: 6px;
        top: 50%;
        transform: translateY(-50%);
        width: 22px;
        height: 64px;
        border: 1px solid #d7ead3;
        border-radius: 12px;
        background: #fffefb;
        color: #158a18;
        display: grid;
        place-items: center;
        cursor: pointer;
        padding: 0;
        box-shadow: 0 2px 10px rgba(32, 33, 36, 0.08);
        z-index: 2147483647;
      }

      .fold-toggle:hover {
        color: #158a18;
        background: #f8fcf7;
      }

      .fold-toggle .fold-icon {
        display: block;
        width: 10px;
        color: currentColor;
        font-family: "Helvetica Neue", Arial, sans-serif;
        font-size: 22px;
        font-weight: 300;
        line-height: 14px;
        text-align: center;
        transform: translateY(-1px);
      }

      .panel.collapsed .fold-toggle {
        left: 0;
        transform: translate(-100%, -50%);
        border-radius: 12px 0 0 12px;
        border-right: 0;
        box-shadow: -4px 0 12px rgba(32, 33, 36, 0.06);
      }

      .panel.collapsed .fold-toggle .fold-icon {
        transform: translate(-0.5px, -1px);
      }

      .panel.collapsed .header,
      .panel.collapsed .list,
      .panel.collapsed .today-dock,
      .panel.collapsed .footer {
        opacity: 0;
        pointer-events: none;
      }

      .header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: clamp(4px, 1vw, 10px);
        padding: clamp(8px, 1.1vw, 12px) clamp(10px, 1.2vw, 14px) clamp(6px, .9vw, 10px);
      }

      .header-left {
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 5px;
      }

      .logo {
        display: block;
        width: clamp(132px, 13vw, 160px);
        max-width: 100%;
        height: auto;
        object-fit: contain;
        object-position: left center;
      }

      .add {
        width: clamp(24px, 2.4vw, 34px);
        height: clamp(24px, 2.4vw, 34px);
        flex: 0 0 auto;
        border: 1px solid #e7e2d8;
        border-radius: clamp(8px, 1vw, 11px);
        background: #fffefb;
        color: #158a18;
        cursor: pointer;
        font-size: clamp(18px, 2vw, 24px);
        line-height: 1;
        display: grid;
        place-items: center;
      }

      .add:hover,
      .add:focus {
        background: #f3f8f2;
        border-color: #d7ead3;
      }

      .profile-controls {
        position: relative;
        display: inline-block;
        max-width: clamp(132px, 13vw, 160px);
      }

      .profile-pill {
        max-width: 100%;
        border: 1px solid transparent;
        border-radius: 999px;
        background: transparent;
        color: #6f7479;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8.5px, .86vw, 10.5px);
        font-weight: 650;
        line-height: 1.2;
        padding: 1px 5px 1px 0;
        display: inline-flex;
        align-items: center;
        gap: 4px;
      }

      .profile-pill:hover,
      .profile-pill:focus {
        color: #158a18;
        background: #f3f8f2;
      }

      .profile-pill-name {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .profile-pill-caret {
        font-size: 9px;
        line-height: 1;
      }

      .profile-menu {
        position: absolute;
        top: calc(100% + 6px);
        left: 0;
        z-index: 8;
        display: none;
        width: min(176px, 72vw);
        padding: 5px;
        border: 1px solid #e7e2d8;
        border-radius: 10px;
        background: #fffefb;
        box-shadow: 0 12px 28px rgba(32, 33, 36, 0.12);
      }

      .profile-menu.open { display: block; }

      .profile-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 18px 18px;
        gap: 2px;
        align-items: center;
      }

      .profile-option,
      .profile-rename-hint,
      .profile-delete,
      .profile-create {
        border: 0;
        background: transparent;
        color: #5f6368;
        cursor: pointer;
        font: inherit;
        font-size: 11px;
      }

      .profile-option {
        min-width: 0;
        text-align: left;
        border-radius: 7px;
        padding: 6px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .profile-option.active,
      .profile-option:hover {
        background: #f3f8f2;
        color: #158a18;
      }

      .profile-rename-hint {
        width: 18px;
        height: 24px;
        border-radius: 7px;
        color: #7fa17c;
        font-size: 12px;
        line-height: 1;
        opacity: .2;
        transition: opacity 120ms ease, color 120ms ease, background 120ms ease;
      }

      .profile-row:hover .profile-rename-hint,
      .profile-rename-hint:focus-visible {
        color: #4f8b4b;
        opacity: .85;
      }

      .profile-rename-hint:hover {
        background: #f3f8f2;
        opacity: 1;
      }

      .profile-delete {
        min-width: 18px;
        height: 24px;
        border-radius: 7px;
        color: #b0b4b8;
        font-size: 13px;
        line-height: 1;
      }

      .profile-delete:hover {
        background: #fff2ef;
        color: #b94a37;
      }

      .profile-edit-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto auto;
        gap: 4px;
        align-items: center;
        padding: 3px 0;
      }

      .profile-name-input {
        min-width: 0;
        width: 100%;
        border: 1px solid #d7ead3;
        border-radius: 7px;
        background: white;
        color: #202124;
        font: inherit;
        font-size: 11px;
        padding: 5px 7px;
      }

      .profile-save,
      .profile-cancel {
        border: 0;
        border-radius: 7px;
        cursor: pointer;
        font: inherit;
        font-size: 10px;
        font-weight: 700;
        height: 26px;
        padding: 0 7px;
      }

      .profile-save {
        background: #eff8ee;
        color: #158a18;
      }

      .profile-save:hover {
        background: #e4f3e1;
      }

      .profile-cancel {
        background: transparent;
        color: #9aa0a6;
      }

      .profile-cancel:hover {
        background: #f8f5ef;
        color: #5f6368;
      }

      .profile-confirm-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto auto;
        gap: 4px;
        align-items: center;
        padding: 4px 0;
      }

      .profile-confirm-text {
        min-width: 0;
        color: #6f7479;
        font-size: 10px;
        line-height: 1.25;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .profile-delete-confirm {
        border: 0;
        border-radius: 7px;
        background: #fff2ef;
        color: #b94a37;
        cursor: pointer;
        font: inherit;
        font-size: 10px;
        font-weight: 700;
        height: 26px;
        padding: 0 7px;
      }

      .profile-delete-confirm:hover {
        background: #ffe6df;
      }

      .profile-create {
        width: 100%;
        margin-top: 5px;
        border-top: 1px solid #efebe3;
        color: #158a18;
        font-weight: 700;
        padding: 7px 8px 4px;
        text-align: left;
      }

      .profile-create:hover {
        background: #f3f8f2;
      }

      .list {
        flex: 1;
        overflow-y: auto;
        padding: 4px clamp(10px, 1.2vw, 14px) 10px;
      }

      .item { border-radius: 9px; }
      .item.dragging { opacity: .48; }
      .item.drop-before { box-shadow: inset 0 2px 0 var(--item-color, #24b51e); }
      .item.drop-after { box-shadow: inset 0 -2px 0 var(--item-color, #24b51e); }

      .row {
        width: 100%;
        min-height: clamp(29px, 3.5vw, 36px);
        display: grid;
        grid-template-columns: clamp(9px, .95vw, 13px) minmax(0, 1fr) 20px clamp(9px, 1.1vw, 14px);
        align-items: center;
        gap: clamp(7px, .9vw, 10px);
        padding: 0 clamp(4px, .65vw, 7px);
        border-radius: 9px;
        background: transparent;
        color: #202124;
        text-align: left;
        cursor: pointer;
      }

      .row:hover,
      .item.open > .row {
        background: #f3f8f2;
      }

      .folder-wrap {
        width: clamp(14px, 1.15vw, 17px);
        height: clamp(14px, 1.15vw, 17px);
        display: grid;
        place-items: center;
        flex: 0 0 auto;
      }

      .folder-icon {
        width: 100%;
        height: 100%;
        display: block;
        fill: none;
        stroke: #24b51e;
        stroke-width: 1.7;
        stroke-linecap: round;
        stroke-linejoin: round;
      }

      .row:hover .folder-icon,
      .item.open > .row .folder-icon {
        transform: scale(1.04);
      }

      .title-cell {
        min-width: 0;
        width: 100%;
        display: grid;
        align-items: center;
      }

      .title,
      .title-inline-input {
        grid-area: 1 / 1;
      }

      .title {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: #202124;
        font-size: clamp(9.5px, 1.05vw, 12px);
        font-weight: 550;
        letter-spacing: .005em;
      }

      .title-inline-input {
        display: none;
        width: 100%;
        min-width: 0;
        border: 1px solid #24b51e;
        border-radius: 8px;
        background: white;
        color: #202124;
        font: inherit;
        font-size: clamp(10px, 1.15vw, 12.5px);
        font-weight: 550;
        padding: 5px 7px;
        outline: 2px solid color-mix(in srgb, #24b51e 14%, transparent);
        outline-offset: 1px;
      }

      .row.editing-title .title {
        display: none;
      }

      .row.editing-title .title-inline-input {
        display: block;
      }

      .row-trash {
        width: 20px;
        height: 20px;
        border: 0;
        border-radius: 7px;
        background: transparent;
        color: #b0b4b8;
        cursor: pointer;
        display: grid;
        place-items: center;
        font: inherit;
        font-size: 13px;
        line-height: 1;
        opacity: 0;
        transition: opacity 120ms ease, color 120ms ease, background 120ms ease;
      }

      .row:hover .row-trash,
      .row:focus-within .row-trash {
        opacity: 1;
      }

      .row-trash:hover,
      .row-trash:focus {
        background: #f8f5ef;
        color: #6f7479;
      }

      .trash-view .row-trash {
        display: none;
      }

      .chev {
        font-size: clamp(12px, 1.3vw, 15px);
        opacity: .82;
        text-align: right;
        line-height: 1;
        transition: transform 140ms ease;
      }

      .item.open .chev { transform: rotate(90deg); }

      .editor {
        display: none;
        flex-direction: column;
        gap: 9px;
        margin: 2px 0 8px clamp(10px, 1vw, 16px);
        padding: 5px 4px 5px clamp(8px, 1vw, 12px);
        border-left: 2px solid color-mix(in srgb, var(--item-color, #24b51e) 35%, #efebe3);
      }

      .item.open .editor { display: flex; }

      .title-edit-section {
        display: flex;
        flex-direction: column;
        gap: 5px;
        align-items: stretch;
      }

      .title-actions {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 10px;
      }

      .recent-toggle {
        border: 0;
        background: transparent;
        color: #158a18;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8px, .82vw, 10px);
        padding: 0;
        white-space: nowrap;
      }

      .recent-toggle:hover,
      .recent-toggle.active {
        text-decoration: underline;
      }

      .step-group {
        display: flex;
        flex-direction: column;
        gap: 9px;
        padding-bottom: 2px;
      }

      .completed-list {
        display: none;
        flex-direction: column;
        gap: 6px;
        padding: 2px 0 4px;
      }

      .completed-list.visible {
        display: flex;
      }

      .completed-list:empty { display: none; }

      .review-section-label {
        color: #9aa0a6;
        font-size: clamp(8px, .82vw, 10px);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .04em;
        margin-top: 2px;
      }

      .review-empty {
        color: #9aa0a6;
        font-size: clamp(10px, 1vw, 12px);
        line-height: 1.35;
      }

      .completed-row {
        display: grid;
        grid-template-columns: 16px minmax(0, 1fr) auto;
        align-items: start;
        gap: 7px;
        color: #9aa0a6;
        font-size: clamp(10px, 1vw, 12px);
        position: relative;
      }

      .review-plan-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 8px;
        align-items: start;
        color: #6f7479;
        font-size: clamp(10px, 1vw, 12px);
      }

      .review-plan-text {
        min-width: 0;
        overflow-wrap: anywhere;
        line-height: 1.35;
      }

      .review-plan-date {
        color: #9aa0a6;
        white-space: nowrap;
        font-size: clamp(8px, .82vw, 10px);
      }

      .completed-row input[type="checkbox"] {
        width: 13px;
        height: 13px;
        margin: 0;
        accent-color: #9aa0a6;
      }

      .completed-text {
        text-decoration: line-through;
        overflow: visible;
        text-overflow: clip;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
        line-height: 1.35;
      }

      .make-note {
        border: 0;
        background: transparent;
        color: #9aa0a6;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8px, .82vw, 10px);
        padding: 0;
        white-space: nowrap;
      }

      .make-note:hover {
        color: #158a18;
        text-decoration: underline;
      }

      .completed-note-editor {
        grid-column: 2 / 4;
        display: none;
        margin-top: 2px;
      }

      .completed-note-editor.visible {
        display: block;
      }

      .completed-note-editor textarea {
        width: 100%;
        min-height: 42px;
        resize: vertical;
        border: 1px solid #e7e2d8;
        border-radius: 8px;
        background: #fffefb;
        color: #202124;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        padding: 6px 7px;
      }

      .completed-note-preview {
        display: none;
        position: absolute;
        left: 23px;
        right: 0;
        bottom: calc(100% + 4px);
        z-index: 3;
        color: #6f7479;
        background: #fffefb;
        border: 1px solid #e7e2d8;
        border-radius: 8px;
        box-shadow: 0 8px 18px rgba(32, 33, 36, 0.08);
        font-size: clamp(8px, .82vw, 10px);
        line-height: 1.35;
        padding: 6px 7px;
        white-space: normal;
        word-break: break-word;
      }

      .completed-row.has-note:not(.editing-note):hover .completed-note-preview {
        display: block;
      }

      .completed-row.has-note {
        margin-bottom: 3px;
      }

      .step-line {
        display: grid;
        grid-template-columns: 16px minmax(0, 1fr);
        align-items: center;
        gap: 7px;
      }

      .complete-now {
        width: 14px;
        height: 14px;
        margin: 0;
        accent-color: var(--item-color, #24b51e);
      }

      .free-type-placeholder {
        width: 14px;
        height: 14px;
        border-radius: 4px;
        border: 1px solid #d8d2c8;
      }

      .step-input-wrap {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .step-prefix {
        color: #9aa0a6;
        font-size: clamp(8px, .82vw, 10px);
        font-weight: 650;
        letter-spacing: .12em;
        text-transform: uppercase;
      }

      .now-date {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        letter-spacing: .02em;
        text-transform: none;
      }

      .now-date .date-text {
        color: #202124;
        font-weight: 650;
        letter-spacing: .02em;
        text-transform: none;
      }

      .step-line input[type="text"] {
        width: 100%;
        min-width: 0;
        border: 0;
        border-bottom: 1px solid #e7e2d8;
        background: transparent;
        color: #202124;
        font: inherit;
        font-size: clamp(10px, 1vw, 12px);
        padding: 3px 2px 4px;
      }

      .step-line input[type="text"]::placeholder { color: #b0b4b8; }

      .free-type-line {
        align-items: start;
      }

      .free-type-input {
        width: 100%;
        min-height: 58px;
        resize: vertical;
        border: 1px solid #e7e2d8;
        border-radius: 8px;
        background: #fffefb;
        color: #202124;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.45;
        padding: 6px 7px;
      }

      .free-type-input::placeholder {
        color: #b0b4b8;
      }

      input:focus,
      textarea:focus {
        border-color: #24b51e;
        outline: 2px solid rgba(36, 181, 30, .12);
      }


      .date-block {
        display: flex;
        flex-direction: column;
        gap: 7px;
      }

      .today-lines {
        display: flex;
        flex-direction: column;
        gap: 6px;
        min-height: 36px;
      }



      .add-todo-row {
        display: grid;
        grid-template-columns: 16px minmax(0, 1fr) 14px;
        align-items: start;
        gap: 7px;
        width: 100%;
        padding: 2px 0;
        cursor: pointer;
      }

      .add-todo-button {
        width: 16px;
        height: 18px;
        margin: 2px 0 0;
        border: 0;
        border-radius: 0;
        background: transparent;
        color: #158a18;
        cursor: pointer;
        display: grid;
        place-items: center;
        font: inherit;
        font-size: 16px;
        font-weight: 700;
        line-height: 1;
        padding: 0;
      }

      .add-todo-label {
        display: block;
        color: #8a8f94;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        padding-top: 3px;
        white-space: nowrap;
      }

      .add-todo-row:hover .add-todo-button,
      .add-todo-row:hover .add-todo-label {
        color: #0f7414;
      }


      .todo-line {
        display: grid;
        grid-template-columns: 16px minmax(0, 1fr) 14px;
        align-items: start;
        gap: 7px;
        width: 100%;
        position: relative;
      }

      .todo-check {
        width: 14px;
        height: 14px;
        margin: 4px 0 0;
        accent-color: #78b973;
        opacity: .78;
        flex: 0 0 auto;
        transition: opacity 120ms ease;
      }

      .todo-check:hover,
      .todo-check:focus-visible {
        opacity: 1;
      }

      .todo-input {
        display: block;
        width: 100%;
        max-width: 100%;
        min-width: 0;
        box-sizing: border-box;
        border: 0;
        border-bottom: 1px solid #e7e2d8;
        background: transparent;
        color: #202124;
        font: inherit;
        font-size: clamp(10px, 1vw, 12px);
        padding: 3px 2px 4px;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .todo-link-view {
        display: none;
        width: 100%;
        max-width: 100%;
        min-width: 0;
        box-sizing: border-box;
        color: #202124;
        font: inherit;
        font-size: clamp(10px, 1vw, 12px);
        line-height: 1.35;
        padding: 3px 2px 4px;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .todo-link {
        color: #147d19;
        font-weight: 650;
        text-decoration: underline;
        text-decoration-color: rgba(20, 125, 25, .28);
        text-underline-offset: 2px;
        cursor: pointer;
      }

      .todo-link:hover,
      .todo-link:focus-visible {
        color: #0f7414;
        text-decoration-color: rgba(15, 116, 20, .65);
        outline: none;
      }

      .todo-input::placeholder {
        color: #b0b4b8;
      }

      .todo-line:focus-within .todo-input {
        border-bottom-color: #24b51e;
      }

      .line-delete {
        border: 0;
        background: transparent;
        color: #b0b4b8;
        cursor: pointer;
        font-size: 14px;
        line-height: 1;
        min-width: 14px;
        padding: 2px 0 0;
        transition: opacity 120ms ease, color 120ms ease;
      }

      .line-delete:hover {
        color: #6f7479;
      }

      .todo-line:not(.editing) .todo-input {
        display: none;
        border-bottom-color: transparent;
        cursor: default;
      }

      .todo-line:not(.editing) .todo-link-view {
        display: block;
      }

      .todo-line.editing .todo-input {
        display: block;
        border-bottom-color: #24b51e;
        cursor: text;
      }

      .todo-line:not(.editing) .line-delete {
        opacity: 0;
        pointer-events: none;
      }

      .todo-line.editing .line-delete,
      .todo-line:hover .line-delete,
      .todo-line:focus-within .line-delete {
        opacity: 1;
        pointer-events: auto;
      }

      .todo-line.done .todo-input {
        color: #8a8f94;
        text-decoration: line-through;
      }

      .todo-line.done .todo-link-view {
        color: #8a8f94;
        text-decoration: line-through;
      }

      .todo-line.done .todo-link {
        color: inherit;
        text-decoration-color: rgba(138, 143, 148, .5);
      }

      .dock-todo.done .dock-todo-action {
        color: #8a8f94;
        text-decoration: line-through;
      }

      .today-dock {
        position: relative;
        flex: 0 0 auto;
        height: var(--today-dock-height, 24vh);
        min-height: 112px;
        max-height: 46vh;
        margin-top: 10px;
        border-top: 1px solid #efebe3;
        background: #fffefb;
        padding: 12px clamp(9px, 1.1vw, 14px) 8px;
        overflow-y: auto;
        overflow-x: hidden;
        overscroll-behavior: contain;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: thin;
        display: block;
      }

      .today-dock-resizer {
        position: absolute;
        top: -4px;
        left: 0;
        right: 0;
        height: 8px;
        cursor: ns-resize;
        z-index: 3;
        background: transparent;
      }

      .today-dock-resizer::after {
        content: "";
        position: absolute;
        left: 0;
        right: 0;
        top: 3px;
        height: 1px;
        background: transparent;
      }

      .today-dock-resizer:hover::after,
      .today-dock-resizer.dragging::after {
        background: #cfe8cc;
      }

      .today-dock-header {
        position: sticky;
        top: -12px;
        z-index: 2;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        margin: -1px 0 8px;
        padding: 2px 0 6px;
        background: #fffefb;
      }

      .today-dock-header span {
        color: #9aa0a6;
        font-size: clamp(8px, .82vw, 10px);
        font-weight: 700;
        letter-spacing: .12em;
        text-transform: uppercase;
      }

      .today-dock-header strong {
        color: #202124;
        font-size: clamp(9px, .9vw, 11px);
        font-weight: 650;
      }

      .today-back {
        display: none;
        border: 0;
        background: transparent;
        color: #158a18;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8px, .82vw, 10px);
        font-weight: 700;
        padding: 0;
        white-space: nowrap;
      }

      .today-back.visible {
        display: inline;
      }

      .today-back:hover {
        text-decoration: underline;
      }

      .today-dock-list {
        display: flex;
        flex-direction: column;
        gap: 5px;
        height: auto;
        min-height: calc(100% - 30px);
        overflow: visible;
        padding-right: 2px;
        padding-bottom: 10px;
      }

      .dock-todo {
        display: grid;
        grid-template-columns: 14px minmax(0, 1fr) 14px;
        gap: 7px;
        align-items: start;
        width: 100%;
        flex: 0 0 auto;
        padding: 1px 0;
      }

      .dock-todo input {
        width: 13px;
        height: 13px;
        margin: 0;
        accent-color: #78b973;
        opacity: .78;
        align-self: start;
        transition: opacity 120ms ease;
      }

      .dock-todo input:hover,
      .dock-todo input:focus-visible {
        opacity: 1;
      }

      .dock-todo-text {
        display: flex;
        flex-direction: column;
        gap: 2px;
        min-width: 0;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .dock-todo-main {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        align-items: start;
        gap: 4px;
        min-width: 0;
      }

      .dock-todo-title {
        max-width: clamp(40px, 18vw, 74px);
        border-radius: 999px;
        background: #f3f8f2;
        color: #8a8f94;
        font-size: clamp(7.5px, .74vw, 9px);
        font-weight: 700;
        line-height: 1.2;
        padding: 1px 5px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        opacity: .58;
        transition: opacity 120ms ease, color 120ms ease;
      }

      .dock-todo:hover .dock-todo-title,
      .dock-todo:focus-within .dock-todo-title {
        color: #158a18;
        opacity: 1;
      }

      .dock-todo-action {
        color: #202124;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        white-space: normal;
        overflow: visible;
        text-overflow: clip;
        overflow-wrap: anywhere;
      }

      .dock-todo-action .todo-link {
        font-weight: 650;
      }

      .dock-todo-action-input {
        display: none;
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
        border: 0;
        border-bottom: 1px solid #24b51e;
        background: transparent;
        color: #202124;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        padding: 1px 0 2px;
        resize: none;
        overflow: hidden;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        word-break: break-word;
      }

      .dock-todo.editing-text .dock-todo-main {
        display: none;
      }

      .dock-todo.editing-text .dock-todo-action-input {
        display: block;
      }

      .dock-empty {
        color: #8a8f94;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        padding: 2px 0;
      }


      .import-list {
        border: 0;
        background: transparent;
        color: #158a18;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8px, .82vw, 10px);
        padding: 0;
        white-space: nowrap;
      }

      .import-list:hover {
        text-decoration: underline;
      }

      .import-list.active {
        color: #0f7414;
        text-decoration: underline;
      }

      .import-box {
        display: none;
        margin-left: 23px;
        border: 1px solid #e7e2d8;
        border-radius: 10px;
        background: #fffefb;
        padding: 7px;
        gap: 6px;
      }

      .import-box.visible {
        display: grid;
      }

      .import-textarea {
        width: 100%;
        min-height: 90px;
        resize: vertical;
        border: 0;
        border-bottom: 1px solid #e7e2d8;
        background: transparent;
        color: #202124;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.4;
        padding: 4px 2px 6px;
      }

      .import-textarea::placeholder {
        color: #b0b4b8;
      }

      .import-actions {
        display: flex;
        justify-content: flex-end;
        gap: 7px;
      }

      .import-apply,
      .import-cancel {
        border: 0;
        border-radius: 8px;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8px, .82vw, 10px);
        padding: 5px 8px;
      }

      .import-apply {
        background: #24b51e;
        color: white;
      }

      .import-cancel {
        background: #fffefb;
        color: #6f7479;
        box-shadow: inset 0 0 0 1px #e7e2d8;
      }


      .fold-toggle {
        z-index: 20;
      }

      .panel.collapsed {
        overflow: visible;
      }

      .panel.collapsed .fold-toggle {
        opacity: 1;
        pointer-events: auto;
      }

      .dock-todo.standalone {
        grid-template-columns: 14px minmax(0, 1fr) 14px;
        align-items: center;
      }

      .dock-input {
        width: 100%;
        min-width: 0;
        border: 0;
        border-bottom: 1px solid #e7e2d8;
        background: transparent;
        color: #202124;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        padding: 2px 1px 3px;
      }

      .dock-input::placeholder {
        color: #b0b4b8;
      }

      .dock-input:focus {
        outline: none;
        border-bottom-color: #24b51e;
      }

      .dock-todo.done .dock-input {
        color: #8a8f94;
        text-decoration: line-through;
      }

      .dock-delete {
        border: 0;
        background: transparent;
        color: #b0b4b8;
        cursor: pointer;
        font-size: 14px;
        line-height: 1;
        min-width: 14px;
        padding: 0;
        opacity: 0;
        pointer-events: none;
        transition: opacity 120ms ease, color 120ms ease;
        align-self: start;
      }

      .dock-todo:hover .dock-delete,
      .dock-todo:focus-within .dock-delete,
      .dock-todo.editing-text .dock-delete {
        opacity: 1;
        pointer-events: auto;
      }

      .dock-delete:hover,
      .dock-delete:focus {
        color: #6f7479;
        opacity: 1;
      }


      .today-quick-line {
        width: 100%;
        grid-template-columns: 16px minmax(0, 1fr) 14px;
        align-items: start;
        padding: 1px 0;
      }

      .today-quick-line .todo-line-body {
        min-width: 0;
        width: 100%;
      }

      .today-quick-line .todo-input {
        width: 100%;
        display: block;
        min-width: 0;
        padding-top: 2px;
        padding-bottom: 3px;
      }

      .today-quick-line:not(.editing) .todo-input {
        display: none;
      }

      .today-quick-line .todo-link-view {
        padding-top: 2px;
        padding-bottom: 3px;
      }

      .today-quick-line .todo-check {
        margin: 1px 0 0;
        align-self: start;
      }

      .today-quick-line .line-delete {
        padding: 2px 0 0;
        align-self: start;
      }


      .today-quick-line.done .todo-input {
        color: #8a8f94;
        text-decoration: line-through;
      }

      .today-add-row {
        grid-template-columns: 16px minmax(0, 1fr) 14px;
        align-items: center;
      }


      .today-dock .today-quick-line:not(:hover):not(:focus-within):not(.editing) .line-delete {
        opacity: 0;
        pointer-events: none;
      }

      .today-dock .today-quick-line:hover .line-delete,
      .today-dock .today-quick-line:focus-within .line-delete,
      .today-dock .today-quick-line.editing .line-delete {
        opacity: 1;
        pointer-events: auto;
      }




      textarea.todo-input {
        resize: none;
        overflow: hidden;
        min-height: 26px;
        line-height: 1.35;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        word-break: break-word;
        user-select: text;
        -webkit-user-select: text;
      }

      .footer {
        display: grid;
        grid-template-columns: auto auto auto minmax(max-content, 1fr);
        align-items: center;
        gap: 10px;
        padding: 8px clamp(8px, 1vw, 12px);
        border-top: 1px solid #efebe3;
      }

      .trash {
        min-width: 26px;
        height: 26px;
        border: 0;
        border-radius: 8px;
        background: transparent;
        color: #6f7479;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 0 6px;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
      }

      .trash-icon {
        font-size: 14px;
        line-height: 1;
      }

      .trash-label {
        display: inline;
      }

      .trash.active,
      .trash:hover,
      .trash.drag-over {
        background: #eff8ee;
        color: #158a18;
      }

      .trash.drag-over {
        outline: 2px dashed color-mix(in srgb, var(--drag-color, #24b51e) 60%, #dbe8d7);
        outline-offset: 2px;
      }

      .recover {
        align-self: flex-start;
        border: 0;
        background: transparent;
        color: #158a18;
        cursor: pointer;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        padding: 0;
      }

      .recover:hover {
        text-decoration: underline;
      }


      .footer .daily-note-button {
        flex: 0 0 auto;
        border: 0;
        background: transparent;
        color: #158a18;
        cursor: pointer;
        font: inherit;
        font-size: clamp(9px, .95vw, 12px);
        font-weight: 650;
        line-height: 1.18;
        padding: 0 2px;
        white-space: nowrap;
      }

      .footer .calendar-button {
        flex: 0 0 auto;
        border: 0;
        background: transparent;
        color: #158a18;
        cursor: pointer;
        font: inherit;
        font-size: clamp(9px, .95vw, 12px);
        font-weight: 650;
        line-height: 1.18;
        padding: 0 2px;
        white-space: nowrap;
      }

      .footer .daily-note-button:hover,
      .footer .daily-note-button.active,
      .footer .calendar-button:hover,
      .footer .calendar-button.active {
        text-decoration: underline;
      }


      .daily-note-panel {
        display: none;
        position: absolute;
        left: clamp(8px, 1vw, 12px);
        right: clamp(8px, 1vw, 12px);
        bottom: 48px;
        z-index: 12;
        background: #fffefb;
        border: 1px solid #e7e2d8;
        border-radius: 14px;
        box-shadow: 0 12px 30px rgba(32, 33, 36, 0.16);
        padding: 10px;
      }

      .daily-note-panel.visible {
        display: block;
      }

      .daily-note-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 8px;
      }

      .daily-note-header strong {
        color: #202124;
        font-size: clamp(11px, 1.05vw, 13px);
      }

      .daily-note-date {
        color: #9aa0a6;
        font-size: clamp(8px, .82vw, 10px);
        font-weight: 650;
      }

      .daily-note-textarea {
        width: 100%;
        min-height: 160px;
        max-height: 42vh;
        resize: vertical;
        border: 1px solid #e7e2d8;
        border-radius: 10px;
        background: #fffefb;
        color: #202124;
        font: inherit;
        font-size: clamp(10px, 1vw, 12px);
        line-height: 1.45;
        padding: 8px 9px;
      }

      .daily-note-textarea:focus {
        outline: 2px solid #d7ead3;
        border-color: #24b51e;
      }

      .calendar-panel {
        display: none;
        position: absolute;
        left: clamp(8px, 1vw, 12px);
        right: clamp(8px, 1vw, 12px);
        bottom: 48px;
        z-index: 13;
        background: #fffefb;
        border: 1px solid #e7e2d8;
        border-radius: 14px;
        box-shadow: 0 12px 30px rgba(32, 33, 36, 0.16);
        padding: 10px;
        max-height: min(78vh, 620px);
        overflow-y: auto;
      }

      .calendar-panel.visible {
        display: block;
      }

      .calendar-header {
        display: grid;
        grid-template-columns: 28px minmax(0, 1fr) 28px 28px;
        align-items: center;
        gap: 6px;
        margin-bottom: 8px;
      }

      .calendar-title {
        color: #202124;
        font-size: clamp(11px, 1.05vw, 13px);
        font-weight: 700;
        text-align: center;
      }

      .calendar-nav,
      .calendar-close {
        width: 28px;
        height: 26px;
        border: 1px solid #e7e2d8;
        border-radius: 8px;
        background: white;
        color: #158a18;
        cursor: pointer;
        font: inherit;
        display: grid;
        place-items: center;
        padding: 0;
      }

      .calendar-weekdays,
      .calendar-grid {
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
        gap: 4px;
      }

      .calendar-weekday {
        color: #9aa0a6;
        font-size: 9px;
        font-weight: 700;
        text-align: center;
      }

      .calendar-grid {
        margin-top: 5px;
      }

      .calendar-detail-tools {
        display: flex;
        justify-content: flex-end;
        margin-top: 8px;
      }

      .calendar-detail-toggle {
        border: 0;
        background: transparent;
        color: #6f7479;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8px, .82vw, 10px);
        font-weight: 700;
        padding: 2px 0;
      }

      .calendar-detail-toggle:hover,
      .calendar-detail-toggle.active {
        color: #158a18;
      }

      .calendar-month-details {
        display: none;
        flex-direction: column;
        gap: 10px;
        margin-top: 8px;
        padding-top: 10px;
      }

      .calendar-month-details.visible {
        display: flex;
      }

      .calendar-detail-day {
        display: grid;
        grid-template-columns: 52px minmax(0, 1fr);
        gap: 8px;
        align-items: start;
      }

      .calendar-detail-date {
        border: 0;
        background: transparent;
        color: #6f7479;
        cursor: pointer;
        font: inherit;
        font-size: 9px;
        font-weight: 700;
        line-height: 1.3;
        padding: 2px 0;
        text-align: left;
      }

      .calendar-detail-date:hover {
        color: #158a18;
      }

      .calendar-detail-items {
        display: flex;
        flex-direction: column;
        gap: 5px;
        min-width: 0;
      }

      .calendar-detail-item {
        display: grid;
        grid-template-columns: 7px minmax(0, 1fr) auto;
        gap: 6px;
        align-items: start;
        color: #44484b;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        min-width: 0;
      }

      .calendar-detail-dot {
        width: 6px;
        height: 6px;
        border-radius: 999px;
        background: #24b51e;
        margin-top: 4px;
      }

      .calendar-detail-text {
        min-width: 0;
        overflow-wrap: anywhere;
      }

      .calendar-detail-meta {
        max-width: 72px;
        color: #9aa0a6;
        font-size: 8px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .calendar-detail-empty {
        color: #9aa0a6;
        font-size: clamp(9px, .9vw, 11px);
        padding: 2px 0;
      }

      .calendar-day {
        min-height: 42px;
        border: 1px solid #efebe3;
        border-radius: 8px;
        background: white;
        color: #202124;
        cursor: pointer;
        font: inherit;
        padding: 4px;
        text-align: left;
        display: flex;
        flex-direction: column;
        gap: 3px;
      }

      .calendar-day.other-month {
        opacity: .38;
      }

      .calendar-day.today {
        border-color: #24b51e;
      }

      .calendar-day.selected {
        background: #f3f8f2;
        border-color: #24b51e;
      }

      .calendar-day-number {
        font-size: 10px;
        font-weight: 700;
        line-height: 1;
      }

      .calendar-day-dots {
        display: flex;
        align-items: center;
        gap: 3px;
        min-height: 6px;
      }

      .calendar-dot {
        width: 5px;
        height: 5px;
        border-radius: 999px;
        background: #24b51e;
      }

      .calendar-dot.deadline {
        background: #b7791f;
      }

      .calendar-dot.label {
        background: #8a9b4a;
      }

      .calendar-selected {
        display: none;
      }

      .calendar-selected.hidden {
        display: none;
      }

      .calendar-selected-title {
        color: #202124;
        font-size: clamp(10px, 1vw, 12px);
        font-weight: 700;
      }

      .calendar-mode-toggle {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4px;
        border: 1px solid #e7e2d8;
        border-radius: 9px;
        padding: 3px;
        background: white;
      }

      .calendar-mode {
        border: 0;
        border-radius: 7px;
        background: transparent;
        color: #6f7479;
        cursor: pointer;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        font-weight: 650;
        padding: 5px 6px;
      }

      .calendar-mode.active {
        background: #f3f8f2;
        color: #158a18;
      }

      .calendar-day-list {
        display: grid;
        gap: 4px;
        color: #6f7479;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        max-height: 132px;
        overflow-y: auto;
        border-top: 1px solid #efebe3;
        padding-top: 7px;
      }

      .calendar-day-empty {
        color: #9aa0a6;
      }

      .calendar-edit-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 16px;
        gap: 6px;
        align-items: center;
        min-height: 26px;
      }

      .calendar-edit-body {
        min-width: 0;
        display: grid;
        grid-template-columns: auto minmax(0, 1fr);
        gap: 6px;
        align-items: center;
      }

      .calendar-edit-row textarea,
      .calendar-edit-row input {
        width: 100%;
        min-width: 0;
        border: 0;
        border-bottom: 1px solid transparent;
        background: transparent;
        color: #202124;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
        padding: 2px 0 3px;
      }

      .calendar-edit-row textarea {
        min-height: 22px;
        resize: none;
        overflow: hidden;
      }

      .calendar-edit-row textarea:focus,
      .calendar-edit-row input:focus {
        border-bottom-color: #24b51e;
        outline: none;
      }

      .calendar-edit-meta {
        display: inline-block;
        max-width: 92px;
        color: #9aa0a6;
        font-size: 8px;
        font-weight: 700;
        line-height: 1.2;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .calendar-edit-delete {
        border: 0;
        background: transparent;
        color: #b0b4b8;
        cursor: pointer;
        font: inherit;
        font-size: 14px;
        line-height: 1;
        padding: 2px 0 0;
        opacity: 0;
        pointer-events: none;
      }

      .calendar-edit-row:hover .calendar-edit-delete,
      .calendar-edit-row:focus-within .calendar-edit-delete {
        opacity: 1;
        pointer-events: auto;
      }

      .calendar-add-form {
        display: grid;
        gap: 6px;
      }

      .calendar-label-form {
        display: grid;
        gap: 6px;
      }

      .calendar-add-form.hidden,
      .calendar-label-form.hidden {
        display: none;
      }

      .calendar-add-form textarea,
      .calendar-add-form select,
      .calendar-add-form input[type="date"],
      .calendar-label-form input,
      .calendar-label-form select {
        width: 100%;
        min-width: 0;
        border: 1px solid #e7e2d8;
        border-radius: 8px;
        background: white;
        color: #202124;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        padding: 6px 7px;
      }

      .calendar-add-form textarea {
        min-height: 46px;
        resize: vertical;
        line-height: 1.35;
      }

      .calendar-form-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
        gap: 6px;
      }

      .calendar-deadline-row {
        display: grid;
        grid-template-columns: auto minmax(0, 1fr);
        align-items: center;
        gap: 7px;
        color: #6f7479;
        font-size: clamp(9px, .9vw, 11px);
      }

      .calendar-deadline-row input[type="checkbox"] {
        width: 13px;
        height: 13px;
        margin: 0;
        accent-color: #24b51e;
      }

      .calendar-deadline-input {
        display: none;
        grid-column: 1 / 3;
      }

      .calendar-deadline-row.active .calendar-deadline-input {
        display: block;
      }

      .calendar-add {
        justify-self: end;
        border: 0;
        border-radius: 8px;
        background: #24b51e;
        color: white;
        cursor: pointer;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        font-weight: 650;
        padding: 6px 10px;
      }

      .calendar-label-add {
        justify-self: end;
        border: 0;
        border-radius: 8px;
        background: #eef2ff;
        color: #3343a4;
        cursor: pointer;
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        font-weight: 650;
        padding: 6px 10px;
      }

      .calendar-info-row {
        display: grid;
        grid-template-columns: 14px minmax(0, 1fr);
        gap: 7px;
        align-items: start;
        color: #6f7479;
        font-size: clamp(9px, .9vw, 11px);
        line-height: 1.35;
      }

      .calendar-info-icon {
        width: 8px;
        height: 8px;
        margin-top: 4px;
        border-radius: 999px;
        background: #5b6ee1;
      }

      .calendar-info-row.deadline .calendar-info-icon {
        background: #b7791f;
      }

      .special-day-zone {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 4px;
        margin-top: auto;
        padding-top: 16px;
      }

      .special-day-row {
        max-width: 82%;
        display: grid;
        grid-template-columns: auto minmax(0, 1fr) 14px;
        align-items: center;
        gap: 6px;
        min-height: 20px;
        background: transparent;
        padding: 1px 2px;
      }

      .special-day-input {
        width: 100%;
        min-width: 0;
        border: 0;
        border-bottom: 1px solid transparent;
        background: transparent;
        color: var(--special-color, #6f7f9f);
        font: inherit;
        font-size: clamp(9px, .9vw, 11px);
        font-weight: 700;
        padding: 1px 0 2px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .special-day-input[readonly] {
        cursor: text;
      }

      .special-day-input[readonly]:hover {
        border-bottom-color: color-mix(in srgb, var(--special-color, #b45f6a) 28%, transparent);
      }

      .special-day-input:not([readonly]),
      .special-day-input:focus {
        border-bottom-color: var(--special-color, #6f7f9f);
        outline: none;
      }

      .special-day-row.editing .special-day-input {
        border-radius: 4px 4px 0 0;
        background: color-mix(in srgb, var(--special-color, #b45f6a) 8%, transparent);
        padding-left: 4px;
        padding-right: 4px;
      }

      .special-day-row.editing .special-day-input::placeholder {
        color: color-mix(in srgb, var(--special-color, #b45f6a) 42%, #9aa0a6);
        font-style: italic;
        font-weight: 500;
        opacity: .72;
      }

      .special-day-color-wrap {
        position: relative;
        display: grid;
        place-items: center;
      }

      .special-day-color {
        width: 10px;
        height: 10px;
        border: 0;
        border-radius: 999px;
        background: var(--special-color, #6f7f9f);
        cursor: pointer;
        padding: 0;
      }

      .special-day-palette {
        position: absolute;
        left: -4px;
        bottom: calc(100% + 5px);
        z-index: 4;
        display: none;
        align-items: center;
        gap: 4px;
        border: 1px solid #e7e2d8;
        border-radius: 999px;
        background: #fffefb;
        box-shadow: 0 5px 14px rgba(32, 33, 36, .1);
        padding: 4px 5px;
      }

      .special-day-color-wrap.open .special-day-palette {
        display: flex;
      }

      .special-day-swatch {
        width: 12px;
        height: 12px;
        border: 1px solid rgba(32, 33, 36, .1);
        border-radius: 999px;
        background: var(--swatch-color);
        cursor: pointer;
        padding: 0;
      }

      .special-day-swatch.active {
        outline: 2px solid color-mix(in srgb, var(--swatch-color) 45%, white);
        outline-offset: 1px;
      }

      .special-day-delete {
        border: 0;
        background: transparent;
        color: color-mix(in srgb, var(--special-color, #6f7f9f) 70%, #9aa0a6);
        cursor: pointer;
        font: inherit;
        font-size: 14px;
        line-height: 1;
        padding: 0;
        opacity: 0;
        pointer-events: none;
      }

      .special-day-row:hover .special-day-delete,
      .special-day-row:focus-within .special-day-delete {
        opacity: 1;
        pointer-events: auto;
      }

      .special-day-add-row {
        border: 1px solid #dfe3eb;
        border-radius: 999px;
        background: #f5f7fa;
        color: #6f7f9f;
        cursor: pointer;
        font: inherit;
        font-size: clamp(8px, .82vw, 10px);
        font-weight: 700;
        padding: 3px 7px;
        opacity: .66;
        transition: opacity 120ms ease, background 120ms ease, border-color 120ms ease;
      }

      .special-day-add-row:hover,
      .special-day-add-row:focus {
        border-color: #cbd3df;
        background: #edf1f6;
        opacity: 1;
        outline: none;
      }

      .todo-deadline {
        display: block;
        color: #9a6a16;
        font-size: clamp(8px, .82vw, 10px);
        line-height: 1.25;
        margin-top: 2px;
      }

      .todo-deadline.overdue {
        color: #b3261e;
      }

      .todo-deadline.due-today {
        color: #b7791f;
        font-weight: 700;
      }


      .web {
        justify-self: end;
        display: inline-flex;
        flex-direction: column;
        align-items: flex-end;
        text-align: right;
        color: #202124;
        text-decoration: none;
        font-size: clamp(9px, .95vw, 12px);
        font-weight: 650;
        line-height: 1.18;
        white-space: nowrap;
        cursor: pointer;
      }

      .web small {
        display: block;
        color: #6f7479;
        font-size: clamp(8px, .8vw, 10px);
        font-weight: 500;
        letter-spacing: .01em;
        max-width: none;
        white-space: nowrap;
        margin-top: 1px;
      }

      .web:hover,
      .web:focus-visible {
        color: #158a18;
        outline: none;
      }

      .web:hover small,
      .web:focus-visible small {
        color: #158a18;
      }


      .completion-date {
        color: #8a8f94;
        font-size: clamp(8px, .82vw, 10px);
        white-space: nowrap;
      }

      .completed-row input[type="checkbox"] {
        cursor: pointer;
      }

      .completed-row.has-note {
        margin-top: 2px;
      }

      .todo-line {
        align-items: start;
      }

      .todo-line-body {
        display: flex;
        flex-direction: column;
        gap: 4px;
        min-width: 0;
      }

      .panel.sidepanel .fold-toggle {
        display: none;
      }


      .panel.appwindow {
        width: 100vw !important;
        min-width: 100vw !important;
        max-width: 100vw !important;
        height: 100vh !important;
        border-left: 0;
        box-shadow: none;
      }

      .panel.appwindow .fold-toggle,
      .panel.appwindow .resize-handle {
        display: none;
      }


      .panel.embedded {
        position: relative !important;
        inset: auto !important;
        width: 100% !important;
        min-width: 0 !important;
        max-width: none !important;
        height: 100dvh !important;
        border-left: 1px solid #efebe3;
        box-shadow: none;
      }

      .panel.appwindow.embedded {
        width: 100% !important;
        min-width: 0 !important;
        max-width: 100% !important;
      }

      .panel.embedded .fold-toggle,
      .panel.embedded .resize-handle {
        display: none;
      }

      @media (max-width: 900px) {
        .web small { display: none; }
        .panel.collapsed { transform: translateX(100%); }
        .fold-toggle {
          width: 16px;
          height: 46px;
        }
      }

      @media (max-width: 760px) {
        .logo { width: 156px; }
        .add {
          width: 24px;
          height: 24px;
        }
        .title { font-size: 10px; }
      }

      @media (max-width: 340px) {
        .header {
          padding: 8px 9px;
        }

        .logo {
          width: min(138px, calc(100vw - 58px));
        }

        .list {
          padding-left: 8px;
          padding-right: 8px;
        }

        .dock-todo {
          grid-template-columns: 13px minmax(0, 1fr) 12px;
          gap: 5px;
        }

        .dock-todo-main {
          display: flex;
          flex-wrap: wrap;
          gap: 3px 5px;
        }

        .dock-todo-action {
          flex: 1 1 100%;
        }

        .dock-todo-title {
          max-width: 58px;
          font-size: 7.5px;
          padding: 1px 4px;
          order: 2;
        }

        .today-dock {
          padding-left: 8px;
          padding-right: 8px;
        }
      }
    </style>

    <aside class="panel" role="complementary" aria-label="Mainline Life Tracker">
      <div class="width-resizer" role="separator" aria-orientation="vertical" title="Drag to resize Mainline width"></div>
      <button class="fold-toggle" type="button" aria-label="Hide or show Mainline"><span class="fold-icon">›</span></button>
      <header class="header">
        <div class="header-left">
          <img class="logo" src="${logoUrl}" alt="Mainline Life Tracker" />
          <div class="profile-controls">
            <button class="profile-pill" type="button" aria-label="Switch profile" title="Switch profile">
              <span class="profile-pill-name"></span>
              <span class="profile-pill-caret">▾</span>
            </button>
            <div class="profile-menu" aria-label="Profiles"></div>
          </div>
        </div>
        <button class="add" type="button" aria-label="Add mainline" title="Add mainline">+</button>
      </header>
      <section class="list" aria-label="Mainlines"></section>
      <section class="today-dock" aria-label="Today to-do list">
        <div class="today-dock-resizer" role="separator" aria-orientation="horizontal" title="Drag to resize Today list height"></div>
        <div class="today-dock-header">
          <span class="today-dock-label">Today</span>
          <strong class="today-dock-date"></strong>
          <button class="today-back" type="button">Today</button>
        </div>
        <div class="today-dock-list"></div>
      </section>
      <section class="daily-note-panel" aria-label="Note panel">
        <div class="daily-note-header">
          <strong>Note</strong>
          <span class="daily-note-date"></span>
        </div>
        <textarea class="daily-note-textarea" spellcheck="true" placeholder="Write anything you want to remember for this day."></textarea>
      </section>
      <section class="calendar-panel" aria-label="Calendar panel">
        <div class="calendar-header">
          <button class="calendar-nav calendar-prev" type="button" aria-label="Previous month">‹</button>
          <strong class="calendar-title"></strong>
          <button class="calendar-nav calendar-next" type="button" aria-label="Next month">›</button>
          <button class="calendar-close" type="button" aria-label="Close calendar">×</button>
        </div>
        <div class="calendar-weekdays" aria-hidden="true">
          <span class="calendar-weekday">Sun</span>
          <span class="calendar-weekday">Mon</span>
          <span class="calendar-weekday">Tue</span>
          <span class="calendar-weekday">Wed</span>
          <span class="calendar-weekday">Thu</span>
          <span class="calendar-weekday">Fri</span>
          <span class="calendar-weekday">Sat</span>
        </div>
        <div class="calendar-grid"></div>
        <div class="calendar-detail-tools">
          <button class="calendar-detail-toggle" type="button" aria-expanded="false">Show details</button>
        </div>
        <div class="calendar-month-details" aria-label="Monthly details"></div>
        <div class="calendar-selected hidden" aria-hidden="true">
          <div class="calendar-selected-title"></div>
          <div class="calendar-mode-toggle" role="tablist" aria-label="Calendar add mode">
            <button class="calendar-mode calendar-mode-todo active" type="button">Todo</button>
            <button class="calendar-mode calendar-mode-label" type="button">Label</button>
          </div>
          <div class="calendar-add-form">
            <textarea class="calendar-todo-text" maxlength="300" spellcheck="true" placeholder="Add an action for this day"></textarea>
            <div class="calendar-form-row">
              <select class="calendar-mainline-select" aria-label="Add to mainline"></select>
            </div>
            <label class="calendar-deadline-row">
              <input class="calendar-deadline-toggle" type="checkbox">
              <span>Deadline optional</span>
              <input class="calendar-deadline-input" type="date" aria-label="Deadline">
            </label>
            <button class="calendar-add" type="button">Add to calendar</button>
          </div>
          <div class="calendar-label-form hidden">
            <input class="calendar-label-text" type="text" maxlength="48" spellcheck="true" placeholder="Add label, e.g. friend's birthday">
            <div class="calendar-form-row">
              <select class="calendar-label-kind" aria-label="Label type">
                <option value="personal">Personal</option>
                <option value="birthday">Birthday</option>
                <option value="deadline">Deadline</option>
                <option value="work">Work</option>
              </select>
            </div>
            <button class="calendar-label-add" type="button">Add label</button>
          </div>
          <div class="calendar-day-list"></div>
        </div>
      </section>

      <footer class="footer">
        <button class="trash" type="button" title="Open Trash. You can also use the × on a folder row." aria-label="Open Trash">
          <span class="trash-icon">×</span>
          <span class="trash-label">Trash</span>
        </button>
        <button class="calendar-button" type="button" title="Open calendar">Calendar</button>
        <button class="daily-note-button" type="button" title="Open note">Note</button>
        <a class="web" href="https://lshangyu23-hash.github.io/mainline-web/" target="_blank" rel="noopener" title="Open Mainline Web">
          Mainline Web
          <small>Power your life.</small>
        </a>
      </footer>
    </aside>
  `;

  const panel = root.querySelector(".panel");
  panel.classList.toggle("appwindow", IS_EXTENSION_PAGE);
  panel.classList.toggle("sidepanel", IS_EXTENSION_PAGE);
  panel.classList.toggle("embedded", IS_MAINLINE_EMBED);
  const widthResizer = root.querySelector(".width-resizer");
  const list = root.querySelector(".list");
  const addBtn = root.querySelector(".add");
  const profilePill = root.querySelector(".profile-pill");
  const profilePillName = root.querySelector(".profile-pill-name");
  const profileMenu = root.querySelector(".profile-menu");
  const trashBtn = root.querySelector(".trash");
  const foldToggle = root.querySelector(".fold-toggle");
  const todayDock = root.querySelector(".today-dock");
  const todayDockResizer = root.querySelector(".today-dock-resizer");
  const todayDockLabel = root.querySelector(".today-dock-label");
  const todayDockDate = root.querySelector(".today-dock-date");
  const todayDockList = root.querySelector(".today-dock-list");
  const todayBackBtn = root.querySelector(".today-back");
  const dailyNotePanel = root.querySelector(".daily-note-panel");
  const dailyNoteButton = root.querySelector(".daily-note-button");
  const dailyNoteDate = root.querySelector(".daily-note-date");
  const dailyNoteTextarea = root.querySelector(".daily-note-textarea");
  const calendarPanel = root.querySelector(".calendar-panel");
  const calendarButton = root.querySelector(".calendar-button");
  const calendarTitle = root.querySelector(".calendar-title");
  const calendarGrid = root.querySelector(".calendar-grid");
  const calendarDetailToggle = root.querySelector(".calendar-detail-toggle");
  const calendarMonthDetails = root.querySelector(".calendar-month-details");
  const calendarSelected = root.querySelector(".calendar-selected");
  const calendarSelectedTitle = root.querySelector(".calendar-selected-title");
  const calendarDayList = root.querySelector(".calendar-day-list");
  const calendarModeTodoBtn = root.querySelector(".calendar-mode-todo");
  const calendarModeLabelBtn = root.querySelector(".calendar-mode-label");
  const calendarAddForm = root.querySelector(".calendar-add-form");
  const calendarLabelForm = root.querySelector(".calendar-label-form");
  const calendarTodoText = root.querySelector(".calendar-todo-text");
  const calendarMainlineSelect = root.querySelector(".calendar-mainline-select");
  const calendarLabelText = root.querySelector(".calendar-label-text");
  const calendarLabelKind = root.querySelector(".calendar-label-kind");
  const calendarLabelAddBtn = root.querySelector(".calendar-label-add");
  const calendarDeadlineToggle = root.querySelector(".calendar-deadline-toggle");
  const calendarDeadlineRow = root.querySelector(".calendar-deadline-row");
  const calendarDeadlineInput = root.querySelector(".calendar-deadline-input");
  const calendarAddBtn = root.querySelector(".calendar-add");
  const calendarPrevBtn = root.querySelector(".calendar-prev");
  const calendarNextBtn = root.querySelector(".calendar-next");
  const calendarCloseBtn = root.querySelector(".calendar-close");

  let state = { mainlines: [], standaloneTodos: [], dailyNotes: {} };
  let isApplyingRemoteState = false;
  let focusTodayQuickDraft = false;
  let focusTodayQuickTodoId = null;
  let isAddingTodoByPlus = false;
  let profileEditingId = null;
  let profileCreating = false;
  let profileDeletingId = null;
  let profileClickTimer = null;
  let openId = null;
  const recentOpenIds = new Set();
  let trashView = false;
  let isCollapsed = false;
  let draggedMainlineId = null;
  let focusBlankForItemId = null;
  let focusBlankTodoId = null;
  let focusTitleForItemId = null;
  let calendarMonthDate = new Date();
  let calendarSelectedDate = null;
  let calendarClickTimer = null;
  let calendarMode = "todo";
  let calendarDetailsVisible = false;
  let activeProfileId = DEFAULT_PROFILE_ID;
  let activeDateKey = todayKey();

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function defaultPanelWidth() {
    return clamp(Math.round(window.innerWidth * 0.2), 240, Math.min(420, Math.round(window.innerWidth * 0.75)));
  }

  function applyPanelWidth() {
    const min = Math.max(220, Math.round(window.innerWidth * 0.14));
    const max = Math.max(min + 40, Math.min(720, Math.round(window.innerWidth * 0.75)));
    const width = clamp(Number(state.panelWidthPx) || defaultPanelWidth(), min, max);
    host.style.setProperty("--mainline-panel-width", `${width}px`);
    requestAnimationFrame(autosizeAllTodoFields);
  }

  function desiredTodayDockHeight() {
    return Math.round(window.innerHeight * (IS_MAINLINE_EMBED ? 0.24 : 0.28));
  }

  function todayDockMinHeight() {
    return Math.max(IS_MAINLINE_EMBED ? 108 : 132, Math.round(window.innerHeight * (IS_MAINLINE_EMBED ? 0.18 : 0.22)));
  }

  function todayDockMaxHeight() {
    return Math.max(todayDockMinHeight() + 20, Math.round(window.innerHeight * (IS_MAINLINE_EMBED ? 0.44 : 0.52)));
  }

  function applyTodayDockHeight() {
    const defaultHeight = desiredTodayDockHeight();
    const min = todayDockMinHeight();
    const max = todayDockMaxHeight();
    const stored = Number(state.todayDockHeightPx);
    const height = clamp(Number.isFinite(stored) && stored > 0 ? stored : defaultHeight, min, max);
    host.style.setProperty("--today-dock-height", `${height}px`);
  }

  function updateCollapsedUI() {
    panel.classList.toggle("collapsed", isCollapsed);
    host.classList.toggle("collapsed-host", isCollapsed);
    foldToggle.setAttribute("aria-label", isCollapsed ? "Expand Mainline" : "Collapse Mainline");
    foldToggle.title = isCollapsed ? "Expand" : "Collapse";
    const icon = foldToggle.querySelector(".fold-icon");
    if (icon) icon.textContent = isCollapsed ? "‹" : "›";
  }

  function scheduleAutoSave(callback, delay = 450) {
    clearTimeout(scheduleAutoSave.timer);
    scheduleAutoSave.timer = setTimeout(callback, delay);
  }

  function scheduleLayoutSave(delay = 120) {
    clearTimeout(scheduleLayoutSave.timer);
    scheduleLayoutSave.timer = setTimeout(saveLayoutOnly, delay);
  }

  function autosizeTodoField(field) {
    if (!field || field.tagName !== "TEXTAREA") return;
    field.style.height = "auto";
    field.style.height = `${field.scrollHeight}px`;
  }

  function autosizeAllTodoFields() {
    try {
      root.querySelectorAll("textarea.todo-input").forEach(autosizeTodoField);
    } catch {
      // Ignore when the panel is not ready.
    }
  }

  function focusTodoInput(input) {
    setTimeout(() => {
      input.focus();
      try { input.setSelectionRange(input.value.length, input.value.length); } catch {}
    }, 0);
  }

  function selectTodoInputText(input) {
    setTimeout(() => {
      input.focus();
      try { input.setSelectionRange(0, input.value.length); } catch {}
    }, 0);
  }

  function parseTodoTextParts(text = "") {
    const source = String(text || "");
    const parts = [];
    const urlPattern = /\b((?:https?:\/\/|www\.)[^\s<>"']+)/gi;
    let lastIndex = 0;
    let match;

    while ((match = urlPattern.exec(source))) {
      if (match.index > lastIndex) {
        parts.push({ type: "text", value: source.slice(lastIndex, match.index) });
      }

      const rawUrl = match[0].replace(/[),.;:!?]+$/g, "");
      const trailing = match[0].slice(rawUrl.length);
      const href = rawUrl.startsWith("www.") ? `https://${rawUrl}` : rawUrl;
      parts.push({ type: "link", value: rawUrl, href });
      if (trailing) parts.push({ type: "text", value: trailing });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < source.length) {
      parts.push({ type: "text", value: source.slice(lastIndex) });
    }

    return parts.length ? parts : [{ type: "text", value: source }];
  }

  function updateTodoLinkView(container, text = "") {
    if (!container) return;
    container.replaceChildren();
    for (const part of parseTodoTextParts(text)) {
      if (part.type !== "link") {
        container.appendChild(document.createTextNode(part.value));
        continue;
      }

      const link = document.createElement("a");
      link.className = "todo-link";
      link.href = part.href;
      link.textContent = part.value;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.title = `Open ${part.value}`;
      container.appendChild(link);
    }
  }

  function handleTodoLinkClick(event) {
    const link = event.target?.closest?.(".todo-link");
    if (!link) return false;
    event.preventDefault();
    event.stopPropagation();
    const url = link.href;

    if (!/^https?:\/\//.test(url)) return true;

    try {
      const sendMessage = chrome.runtime?.sendMessage;
      if (typeof sendMessage !== "function") {
        window.open(url, "_blank", "noopener,noreferrer");
        return true;
      }

      sendMessage({ type: "MAINLINE_OPEN_LINK", url }, () => {
        if (chrome.runtime?.lastError) {
          window.open(url, "_blank", "noopener,noreferrer");
        }
      });
    } catch {
      window.open(url, "_blank", "noopener,noreferrer");
    }
    return true;
  }

  function formatToday() {
    return new Intl.DateTimeFormat(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric"
    }).format(new Date());
  }

  function todayKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }

  function todoDate(todo) {
    return todo?.scheduledFor || todo?.createdFor || todayKey();
  }

  function formatDateKey(dateKey) {
    const [year, month, day] = String(dateKey || todayKey()).split("-").map(Number);
    const d = new Date(year, (month || 1) - 1, day || 1);
    return new Intl.DateTimeFormat(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric"
    }).format(d);
  }

  function activeDateLabel() {
    return activeDateKey === todayKey() ? "Today" : "Planned";
  }

  function deadlineText(todo) {
    if (!todo?.deadlineFor) return "";
    if (todo.deadlineFor < todayKey()) return `Overdue ${formatDateKey(todo.deadlineFor)}`;
    if (todo.deadlineFor === todayKey()) return "Deadline today";
    return `Deadline ${formatDateKey(todo.deadlineFor)}`;
  }

  function applyDeadlineText(element, todo) {
    if (!element) return;
    element.textContent = deadlineText(todo);
    element.classList.toggle("overdue", Boolean(todo?.deadlineFor && todo.deadlineFor < todayKey()));
    element.classList.toggle("due-today", Boolean(todo?.deadlineFor && todo.deadlineFor === todayKey()));
  }

  function hasTodoContent(todo) {
    return Boolean(String(todo?.text || "").trim());
  }

  function parseImportedTodos(raw = "") {
    const pieces = String(raw || "")
      .replace(/\r/g, "\n")
      .split("\n")
      .flatMap(line => {
        const trimmed = line.trim();
        if (!trimmed) return [];
        if (trimmed.includes(";")) {
          return trimmed.split(";").map(part => part.trim()).filter(Boolean);
        }
        return [trimmed];
      });

    const cleaned = pieces
      .map(line => line
        .replace(/^[-*•]\s+/, "")
        .replace(/^[-*•]\s*\[[ xX]\]\s+/, "")
        .replace(/^\[[ xX]\]\s+/, "")
        .replace(/^\d+[\).\:\-]\s+/, "")
        .trim()
      )
      .filter(Boolean);

    return [...new Set(cleaned)];
  }

  function rolloverUnfinishedTodos() {
    const key = todayKey();
    let changed = state.lastRolloverKey !== key;

    state.mainlines = (state.mainlines || []).map(item => {
      const steps = item.steps || makeSteps();
      let todos = steps.todayTodos || [];
      let itemChanged = false;

      todos = todos
        .filter(todo => {
          const targetDate = todoDate(todo);
          if (targetDate > key) return true;
          if (!todo.done && targetDate !== key && !hasTodoContent(todo)) {
            itemChanged = true;
            return false;
          }
          return true;
        })
        .map(todo => {
          const targetDate = todoDate(todo);
          if (targetDate > key) return todo;
          if (!todo.done && targetDate !== key && hasTodoContent(todo)) {
            itemChanged = true;
            return {
              ...todo,
              createdFor: key,
              scheduledFor: key,
              rolledFrom: targetDate || null,
              keepBlank: false
            };
          }
          return todo;
        });

      if (itemChanged) changed = true;

      return {
        ...item,
        steps: {
          ...steps,
          todayTodos: todos
        }
      };
    });

    let standaloneChanged = false;
    state.standaloneTodos = normalizeStandaloneTodos(state.standaloneTodos || [])
      .filter(todo => {
        const targetDate = todoDate(todo);
        if (targetDate > key) return true;
        if (!todo.done && targetDate !== key && !hasTodoContent(todo)) {
          standaloneChanged = true;
          return false;
        }
        return true;
      })
      .map(todo => {
        const targetDate = todoDate(todo);
        if (targetDate > key) return todo;
        if (!todo.done && targetDate !== key && hasTodoContent(todo)) {
          standaloneChanged = true;
          return {
            ...todo,
            createdFor: key,
            scheduledFor: key,
            rolledFrom: targetDate || null,
            keepBlank: false
          };
        }
        return todo;
      });

    if (standaloneChanged) changed = true;

    state.lastRolloverKey = key;
    return changed;
  }

  function showTodayOnOpen() {
    const key = todayKey();
    activeDateKey = key;
    calendarSelectedDate = null;
    calendarMonthDate = parseDateKey(key);
    todayDockLabel.textContent = activeDateLabel();
    todayDockDate.textContent = formatDateKey(activeDateKey);
  }

  function normalizeCompleted(list) {
    if (!Array.isArray(list)) return [];
    return list
      .filter(done => done && done.text)
      .map(done => ({
        id: done.id || crypto.randomUUID(),
        text: done.text,
        note: done.freeType || done.note || "",
        freeType: done.freeType || done.note || "",
        doneAt: done.doneAt || Date.now()
      }));
  }

  function normalizeTodos(list) {
    if (!Array.isArray(list)) return [];
    return list.map(todo => ({
      id: todo.id || crypto.randomUUID(),
      text: todo.text || "",
      freeType: todo.freeType || "",
      keepBlank: Boolean(todo.keepBlank),
      done: Boolean(todo.done),
      completedId: todo.completedId || null,
      createdFor: todo.createdFor || todayKey(),
      scheduledFor: todo.scheduledFor || todo.createdFor || todayKey(),
      deadlineFor: todo.deadlineFor || "",
      rolledFrom: todo.rolledFrom || "",
      profileId: todo.profileId || activeProfileId,
      createdAt: todo.createdAt || Date.now()
    }));
  }

  function normalizeStandaloneTodos(list) {
    return normalizeTodos(list).map(todo => ({
      ...todo,
      completedId: null
    }));
  }

  function normalizeProfiles(list) {
    const profiles = Array.isArray(list) && list.length ? list : defaultProfiles;
    const normalized = profiles
      .filter(profile => profile && profile.id)
      .map((profile, index) => ({
        id: profile.id,
        name: (() => {
          const name = String(profile.name || "").trim();
          return !name || /^(?:Mainline\s+)?User \d+$/i.test(name) ? `Mainline User ${index + 1}` : name;
        })()
      }));
    return normalized.length ? normalized : defaultProfiles;
  }

  function normalizeCalendarLabels(list) {
    if (!Array.isArray(list)) return [];
    return list
      .filter(label => label && label.date && String(label.text || "").trim())
      .map(label => ({
        id: label.id || crypto.randomUUID(),
        date: label.date,
        text: String(label.text || "").trim(),
        kind: label.kind || "personal",
        color: label.color || "#6f7f9f",
        profileId: label.profileId || activeProfileId,
        createdAt: label.createdAt || Date.now()
      }));
  }

  function activeProfile() {
    return (state.profiles || defaultProfiles).find(profile => profile.id === activeProfileId)
      || (state.profiles || defaultProfiles)[0]
      || defaultProfiles[0];
  }

  function activeStandaloneTodos() {
    return normalizeStandaloneTodos(state.standaloneTodos || [])
      .filter(todo => todo.profileId === activeProfileId);
  }

  function activeCalendarLabelsForDate(dateKey) {
    return normalizeCalendarLabels(state.calendarLabels || [])
      .filter(label => label.profileId === activeProfileId && label.date === dateKey);
  }

  function dailyNoteKey(dateKey = activeDateKey) {
    return `${activeProfileId}:${dateKey}`;
  }

  function stepsFromLegacy(item) {
    if (item.steps) {
      const completed = normalizeCompleted(item.steps.completed);
      if (item.steps.previous) {
        completed.push(makeCompleted(item.steps.previous, item.steps.previousNote || ""));
      }

      let todayTodos = normalizeTodos(item.steps.todayTodos);
      if (!todayTodos.length && item.steps.now) {
        todayTodos = [makeTodo(item.steps.now)];
      }

      const legacyFreeType = item.steps.freeType || item.steps.next || "";
      if (legacyFreeType) {
        const targetIndex = todayTodos.findIndex(todo => !todo.done);
        if (targetIndex >= 0 && !todayTodos[targetIndex].freeType) {
          todayTodos[targetIndex] = { ...todayTodos[targetIndex], freeType: legacyFreeType };
        } else if (!todayTodos.length) {
          todayTodos = [makeTodo("", true, legacyFreeType)];
        }
      }

      return {
        completed,
        todayTodos,
        freeType: ""
      };
    }

    const checklist = Array.isArray(item.checklist) ? item.checklist.filter(check => check && check.text) : [];
    const completed = checklist
      .filter(check => check.done)
      .map(check => ({ id: check.id || crypto.randomUUID(), text: check.text, note: check.note || "", freeType: check.note || "", doneAt: Date.now() }));
    const active = checklist.filter(check => !check.done);
    const legacyFreeType = item.freeType || item.followUp || active[1]?.text || "";

    return {
      completed,
      todayTodos: (active[0]?.text || item.nextMove)
        ? [makeTodo(active[0]?.text || item.nextMove, false, legacyFreeType)]
        : (legacyFreeType ? [makeTodo("", true, legacyFreeType)] : []),
      freeType: ""
    };
  }

  function normalize(item) {
    return {
      id: item.id || crypto.randomUUID(),
      name: item.name || "Untitled",
      steps: stepsFromLegacy(item),
      color: DEFAULT_COLOR,
      profileId: item.profileId || activeProfileId,
      trashed: Boolean(item.trashed),
      deletedAt: item.deletedAt || null,
      updatedAt: item.updatedAt || Date.now()
    };
  }

  function migrateStarterTemplatesIfNeeded() {
    const profileNames = (state.profiles || []).map(profile => profile.name);
    const stillDefaultProfiles = profileNames.length === 2
      && (
        (/^User 1$/i.test(profileNames[0] || "") && /^User 2$/i.test(profileNames[1] || ""))
        || (/^Personal$/i.test(profileNames[0] || "") && /^Work$/i.test(profileNames[1] || ""))
      );

    if (stillDefaultProfiles) {
      state.profiles = [
        { id: state.profiles[0].id || DEFAULT_PROFILE_ID, name: "Mainline User 1" },
        { id: state.profiles[1].id || "profile-2", name: "Mainline User 2" }
      ];
    }

    const activeNames = (state.mainlines || [])
      .filter(item => !item.trashed)
      .map(item => item.name)
      .sort();
    const stillOldSample = activeNames.length === 3
      && activeNames[0] === "Family Time"
      && activeNames[1] === "Hiking"
      && activeNames[2] === "ML Projects";

    const personalItems = (state.mainlines || [])
      .filter(item => !item.trashed && item.profileId === DEFAULT_PROFILE_ID);
    const currentStarterNames = personalItems.map(item => item.name).sort();
    const currentStarterTodos = personalItems
      .flatMap(item => item.steps?.todayTodos || [])
      .map(todo => String(todo.text || "").trim())
      .filter(Boolean)
      .sort();
    const stillCurrentStarterSample = currentStarterNames.length === 3
      && currentStarterNames[0] === "Health & Energy"
      && currentStarterNames[1] === "People I Care About"
      && currentStarterNames[2] === "Start here"
      && currentStarterTodos.length === 4
      && currentStarterTodos[0] === "Edit this todo into one action for today"
      && currentStarterTodos[1] === "Message someone I want to stay close to"
      && currentStarterTodos[2] === "Rename this folder for one real life mainline"
      && currentStarterTodos[3] === "Take a 20-minute walk";

    const stillSoftStarterSample = currentStarterNames.length === 3
      && currentStarterNames[0] === "Body & energy"
      && currentStarterNames[1] === "My mainline"
      && currentStarterNames[2] === "People I love"
      && currentStarterTodos.length === 1
      && currentStarterTodos[0] === "Choose one thing that matters today";

    const stillDirectionStarterSample = currentStarterNames.length === 3
      && currentStarterNames[0] === "Build momentum"
      && currentStarterNames[1] === "Main direction"
      && currentStarterNames[2] === "Stay aligned"
      && currentStarterTodos.length === 1
      && currentStarterTodos[0] === "Choose one small next step";

    const stillMinimalStarterSample = currentStarterNames.length === 2
      && currentStarterNames[0] === "Mainline"
      && currentStarterNames[1] === "Next mainline"
      && currentStarterTodos.length === 1
      && currentStarterTodos[0] === "Move one outcome forward";

    if (stillOldSample || stillCurrentStarterSample || stillSoftStarterSample || stillDirectionStarterSample || stillMinimalStarterSample) {
      state.mainlines = defaultMainlines.map(normalize);
      state.standaloneTodos = [];
      state.calendarLabels = [];
      openId = state.mainlines[0]?.id || null;
    }
  }

  async function load() {
    let result = await chrome.storage.local.get(STORAGE_KEY);
    let loaded = result[STORAGE_KEY];

    if (!loaded) {
      for (const key of OLD_STORAGE_KEYS) {
        const oldResult = await chrome.storage.local.get(key);
        if (oldResult[key]) {
          loaded = oldResult[key];
          break;
        }
      }
    }

    state = loaded || { mainlines: defaultMainlines, standaloneTodos: [] };
    state.profiles = normalizeProfiles(state.profiles);
    calendarDetailsVisible = Boolean(state.calendarDetailsVisible);
    activeProfileId = state.activeProfileId && state.profiles.some(profile => profile.id === state.activeProfileId)
      ? state.activeProfileId
      : state.profiles[0].id;
    state.activeProfileId = activeProfileId;

    const layoutResult = await chrome.storage.local.get(LAYOUT_KEY);
    const layout = layoutResult[LAYOUT_KEY] || {};
    if (Number.isFinite(Number(layout.panelWidthPx))) state.panelWidthPx = Number(layout.panelWidthPx);
    if (Number.isFinite(Number(layout.todayDockHeightPx))) state.todayDockHeightPx = Number(layout.todayDockHeightPx);
    if (
      !Number.isFinite(Number(state.todayDockHeightPx))
      || Number(state.todayDockHeightPx) < todayDockMinHeight()
      || Number(state.todayDockHeightPx) > todayDockMaxHeight()
    ) {
      state.todayDockHeightPx = desiredTodayDockHeight();
    }
    if (typeof layout.collapsed === "boolean") state.collapsed = layout.collapsed;

    state.mainlines = (state.mainlines || []).map(normalize);
    state.standaloneTodos = normalizeStandaloneTodos(state.standaloneTodos || []);
    state.calendarLabels = normalizeCalendarLabels(state.calendarLabels || []);
    migrateStarterTemplatesIfNeeded();
    state.dailyNotes = state.dailyNotes || {};
    rolloverUnfinishedTodos();
    showTodayOnOpen();
    isCollapsed = IS_MAINLINE_EMBED ? false : Boolean(state.collapsed);
    applyPanelWidth();
    applyTodayDockHeight();
    await save();
    render();
  }

  async function save() {
    if (isApplyingRemoteState) return;
    state.collapsed = isCollapsed;
    state.profiles = normalizeProfiles(state.profiles);
    state.activeProfileId = activeProfileId;
    state.standaloneTodos = normalizeStandaloneTodos(state.standaloneTodos || []);
    state.calendarLabels = normalizeCalendarLabels(state.calendarLabels || []);
    state.dailyNotes = state.dailyNotes || {};
    const savedState = { ...state, _clientId: CLIENT_ID };
    await chrome.storage.local.set({
      [STORAGE_KEY]: savedState,
      [LAYOUT_KEY]: {
        panelWidthPx: Number(state.panelWidthPx) || null,
        todayDockHeightPx: Number(state.todayDockHeightPx) || null,
        collapsed: Boolean(isCollapsed),
        updatedAt: Date.now(),
        _clientId: CLIENT_ID
      }
    });
  }

  async function saveLayoutOnly() {
    if (isApplyingRemoteState) return;
    state.collapsed = isCollapsed;
    await chrome.storage.local.set({
      [LAYOUT_KEY]: {
        panelWidthPx: Number(state.panelWidthPx) || null,
        todayDockHeightPx: Number(state.todayDockHeightPx) || null,
        collapsed: Boolean(isCollapsed),
        updatedAt: Date.now(),
        _clientId: CLIENT_ID
      }
    });
  }

  function applyExternalState(nextState) {
    if (!nextState) return;
    isApplyingRemoteState = true;
    state = { ...nextState };
    delete state._clientId;
    calendarDetailsVisible = Boolean(state.calendarDetailsVisible);
    state.profiles = normalizeProfiles(state.profiles);
    activeProfileId = state.activeProfileId && state.profiles.some(profile => profile.id === state.activeProfileId)
      ? state.activeProfileId
      : state.profiles[0].id;
    state.mainlines = (state.mainlines || []).map(normalize);
    state.standaloneTodos = normalizeStandaloneTodos(state.standaloneTodos || []);
    state.calendarLabels = normalizeCalendarLabels(state.calendarLabels || []);
    showTodayOnOpen();
    isCollapsed = IS_MAINLINE_EMBED ? false : Boolean(state.collapsed);
    applyPanelWidth();
    applyTodayDockHeight();
    render();
    isApplyingRemoteState = false;
  }

  function applyExternalLayout(layout) {
    if (!layout) return;
    isApplyingRemoteState = true;
    if (Number.isFinite(Number(layout.panelWidthPx))) state.panelWidthPx = Number(layout.panelWidthPx);
    if (Number.isFinite(Number(layout.todayDockHeightPx))) state.todayDockHeightPx = Number(layout.todayDockHeightPx);
    if (!IS_MAINLINE_EMBED && typeof layout.collapsed === "boolean") isCollapsed = layout.collapsed;
    applyPanelWidth();
    applyTodayDockHeight();
    updateCollapsedUI();
    isApplyingRemoteState = false;
  }

  function items() {
    return state.mainlines.filter(item =>
      item.profileId === activeProfileId && (trashView ? item.trashed : !item.trashed)
    );
  }

  function moveItemInArray(array, fromIndex, toIndex) {
    if (fromIndex === toIndex || fromIndex < 0 || toIndex < 0) return array;
    const copy = [...array];
    const [moved] = copy.splice(fromIndex, 1);
    copy.splice(toIndex, 0, moved);
    return copy;
  }

  async function reorderMainlines(dragId, targetId, placeAfter) {
    if (!dragId || !targetId || dragId === targetId) return;

    const visibleIds = items().map(item => item.id);
    const from = visibleIds.indexOf(dragId);
    let to = visibleIds.indexOf(targetId);
    if (from === -1 || to === -1) return;

    if (placeAfter) to += 1;
    if (from < to) to -= 1;

    const reorderedIds = moveItemInArray(visibleIds, from, to);
    const activeSet = new Set(reorderedIds);
    const reorderedMap = new Map(state.mainlines.map(item => [item.id, item]));
    const reorderedGroup = reorderedIds.map(id => reorderedMap.get(id)).filter(Boolean);

    const result = [];
    let inserted = false;

    for (const item of state.mainlines) {
      if (activeSet.has(item.id)) {
        if (!inserted) {
          result.push(...reorderedGroup);
          inserted = true;
        }
      } else {
        result.push(item);
      }
    }

    state.mainlines = result;
    await save();
    render();
  }

  async function updateItem(id, patch) {
    state.mainlines = state.mainlines.map(item => item.id === id
      ? { ...item, ...patch, updatedAt: Date.now() }
      : item
    );
    await save();
  }

  function formatDoneDate(timestamp) {
    return new Intl.DateTimeFormat(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric"
    }).format(new Date(timestamp || Date.now()));
  }

  function getCompletedFreeType(done) {
    return done?.freeType || done?.note || "";
  }

  async function uncheckCompleted(itemId, completedId) {
    const item = findMainline(itemId);
    if (!item) return;

    const done = (item.steps.completed || []).find(entry => entry.id === completedId);
    if (!done) return;

    state.mainlines = state.mainlines.map(old => {
      if (old.id !== itemId) return old;

      const linkedTodo = (old.steps.todayTodos || []).find(todo => todo.completedId === completedId);
      let todayTodos = old.steps.todayTodos || [];

      if (linkedTodo) {
        todayTodos = todayTodos.map(todo => todo.id === linkedTodo.id
          ? { ...todo, done: false, completedId: null, freeType: getCompletedFreeType(done) || todo.freeType || "" }
          : todo
        );
      } else {
        todayTodos = [
          ...todayTodos,
          makeTodo(done.text || "", false, getCompletedFreeType(done))
        ];
      }

      return {
        ...old,
        steps: {
          ...old.steps,
          completed: (old.steps.completed || []).filter(entry => entry.id !== completedId),
          todayTodos
        },
        updatedAt: Date.now()
      };
    });

    await save();
    render();
  }

  function addReviewSectionLabel(container, text) {
    const label = document.createElement("div");
    label.className = "review-section-label";
    label.textContent = text;
    container.appendChild(label);
  }

  function renderReview(container, item, itemId) {
    container.innerHTML = "";

    const todos = item?.steps?.todayTodos || [];
    const carriedPlans = todos
      .filter(todo => todo && !todo.done && todo.rolledFrom && todoDate(todo) !== todo.rolledFrom && String(todo.text || "").trim())
      .sort((a, b) => String(b.rolledFrom).localeCompare(String(a.rolledFrom)))
      .slice(0, 5);

    if (carriedPlans.length) {
      addReviewSectionLabel(container, "Earlier plans");
      for (const todo of carriedPlans) {
        const planRow = document.createElement("div");
        planRow.className = "review-plan-row";
        planRow.innerHTML = `
          <span class="review-plan-text"></span>
          <span class="review-plan-date"></span>
        `;
        planRow.querySelector(".review-plan-text").textContent = todo.text;
        planRow.querySelector(".review-plan-date").textContent = formatDateKey(todo.rolledFrom);
        container.appendChild(planRow);
      }
    }

    const completed = item?.steps?.completed || [];
    const recentItems = [...(completed || [])]
      .filter(done => done && done.text)
      .sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0))
      .slice(0, 8);

    if (recentItems.length) {
      addReviewSectionLabel(container, "Completed");
    }

    for (const doneItem of recentItems) {
      const freeType = getCompletedFreeType(doneItem);
      const doneRow = document.createElement("div");
      doneRow.className = `completed-row ${freeType ? "has-note" : ""}`;
      doneRow.dataset.completedId = doneItem.id;
      doneRow.innerHTML = `
        <input type="checkbox" checked aria-label="Uncheck completed item">
        <span class="completed-text"></span>
        <span class="completion-date"></span>
        <div class="completed-note-preview"></div>
      `;

      doneRow.querySelector(".completed-text").textContent = doneItem.text;
      doneRow.querySelector(".completion-date").textContent = formatDoneDate(doneItem.doneAt);
      doneRow.querySelector(".completed-note-preview").textContent = freeType;
      doneRow.querySelector("input").addEventListener("change", async event => {
        if (!event.target.checked) {
          await uncheckCompleted(itemId, doneItem.id);
        }
      });

      container.appendChild(doneRow);
    }

    if (!carriedPlans.length && !recentItems.length) {
      const empty = document.createElement("div");
      empty.className = "review-empty";
      empty.textContent = "No earlier plans or completed actions yet.";
      container.appendChild(empty);
    }
  }


  function findMainline(id) {
    return state.mainlines.find(item => item.id === id);
  }

  async function toggleTodoDone(itemId, todoId, done) {
    const item = findMainline(itemId);
    if (!item) return;

    const todos = item.steps?.todayTodos || [];
    const todo = todos.find(t => t.id === todoId);
    const text = todo?.text?.trim();

    if (!text) return;

    let completedId = todo.completedId || null;

    state.mainlines = state.mainlines.map(old => {
      if (old.id !== itemId) return old;

      let completed = [...(old.steps.completed || [])];
      const oldTodo = (old.steps.todayTodos || []).find(t => t.id === todoId);
      const todoFreeType = oldTodo?.freeType || "";

      if (done) {
        if (!completedId) {
          const completedItem = makeCompleted(text, todoFreeType);
          completedId = completedItem.id;
          completed.push(completedItem);
        } else {
          completed = completed.map(doneItem => doneItem.id === completedId
            ? { ...doneItem, text, note: todoFreeType, freeType: todoFreeType, doneAt: doneItem.doneAt || Date.now() }
            : doneItem
          );
        }
      } else if (completedId) {
        completed = completed.filter(doneItem => doneItem.id !== completedId);
        completedId = null;
      }

      let todayTodos = (old.steps.todayTodos || []).map(t => t.id === todoId
        ? { ...t, done, completedId, keepBlank: false }
        : t
      );

      return {
        ...old,
        steps: {
          ...old.steps,
          completed,
          todayTodos
        },
        updatedAt: Date.now()
      };
    });

    await save();
    render();
  }


  async function removeTodo(itemId, todoId) {
    if (todoId === "draft") {
      render();
      return;
    }

    state.mainlines = state.mainlines.map(old => {
      if (old.id !== itemId) return old;

      const todo = (old.steps.todayTodos || []).find(t => t.id === todoId);
      const completedId = todo?.completedId || null;

      return {
        ...old,
        steps: {
          ...old.steps,
          completed: completedId
            ? (old.steps.completed || []).filter(doneItem => doneItem.id !== completedId)
            : (old.steps.completed || []),
          todayTodos: (old.steps.todayTodos || []).filter(t => t.id !== todoId)
        },
        updatedAt: Date.now()
      };
    });

    await save();
    render();
  }

  async function moveMainlineToTrash(itemId) {
    if (!itemId) return;
    state.mainlines = state.mainlines.map(item => item.id === itemId ? {
      ...item,
      trashed: true,
      deletedAt: Date.now(),
      updatedAt: Date.now()
    } : item);
    if (openId === itemId) openId = null;
    draggedMainlineId = null;
    await save();
    render();
  }

  async function createOrFocusMainlineTodo(itemId, focusSurface = "folder") {
    const item = findMainline(itemId);
    if (!item) return;

    const created = makeTodo("", true, "", activeDateKey);
    if (focusSurface === "today") {
      focusTodayQuickTodoId = created.id;
    } else {
      focusBlankTodoId = created.id;
    }

    state.mainlines = state.mainlines.map(old => {
      if (old.id !== itemId) return old;
      return {
        ...old,
        steps: {
          ...old.steps,
          todayTodos: [...(old.steps.todayTodos || []), created]
        },
        updatedAt: Date.now()
      };
    });

    if (focusSurface === "today") {
      focusBlankForItemId = null;
    } else {
      focusBlankForItemId = itemId;
    }
    await save();
    render();

    if (focusSurface === "today") {
      setTimeout(() => {
        const target = todayDockList.querySelector(`.dock-todo[data-todo-id="${created.id}"]`);
        const input = target?.querySelector(".dock-todo-action-input");
        if (target && input) {
          target.classList.add("editing-text");
          focusTodoInput(input);
          target.scrollIntoView({ block: "nearest" });
          try { todayDock.scrollTop = todayDock.scrollHeight; } catch {}
        }
      }, 0);
    }
  }


  async function addStandaloneTodo(text = "") {
    if (!String(text || "").trim()) {
      await createOrFocusStandaloneTodo();
      return;
    }

    state.standaloneTodos = [
      ...(state.standaloneTodos || []),
      makeTodo(text, false, "", activeDateKey)
    ];
    await save();
    render();
  }

  async function createOrFocusStandaloneTodo() {
    const created = makeTodo("", true, "", activeDateKey);
    focusTodayQuickTodoId = created.id;
    state.standaloneTodos = [...(state.standaloneTodos || []), created];
    await save();

    focusTodayQuickDraft = true;
    renderTodayDock();

    setTimeout(() => {
      const target = [...todayDockList.querySelectorAll(".today-quick-line")]
        .find(row => row.dataset.todoId === focusTodayQuickTodoId);
      const input = target?.querySelector(".todo-input")
        || [...todayDockList.querySelectorAll(".today-quick-line .todo-input")].find(input => !input.value.trim());
      focusTodoInput(input);
      input?.scrollIntoView({ block: "nearest" });
      try { todayDock.scrollTop = todayDock.scrollHeight; } catch {}
    }, 0);
  }

  async function updateStandaloneTodo(todoId, patch) {
    state.standaloneTodos = (state.standaloneTodos || []).map(todo =>
      todo.id === todoId ? { ...todo, ...patch, keepBlank: false } : todo
    );
    await save();
  }

  async function removeStandaloneTodo(todoId) {
    state.standaloneTodos = (state.standaloneTodos || []).filter(todo => todo.id !== todoId);
    await save();
    render();
  }

  function renderProfileControls() {
    const profiles = normalizeProfiles(state.profiles);
    const active = activeProfile();
    profilePillName.textContent = active.name;
    profileMenu.innerHTML = "";

    for (const profile of profiles) {
      if (profileDeletingId === profile.id) {
        const confirmRow = document.createElement("div");
        confirmRow.className = "profile-confirm-row";

        const label = document.createElement("span");
        label.className = "profile-confirm-text";
        label.textContent = `Delete ${profile.name}?`;

        const confirm = document.createElement("button");
        confirm.className = "profile-delete-confirm";
        confirm.type = "button";
        confirm.dataset.profileAction = "confirm-delete";
        confirm.dataset.profileId = profile.id;
        confirm.textContent = "Delete";

        const cancel = document.createElement("button");
        cancel.className = "profile-cancel";
        cancel.type = "button";
        cancel.dataset.profileAction = "cancel-edit";
        cancel.textContent = "Cancel";

        confirmRow.append(label, confirm, cancel);
        profileMenu.appendChild(confirmRow);
        continue;
      }

      if (profileEditingId === profile.id) {
        const editRow = document.createElement("div");
        editRow.className = "profile-edit-row";
        editRow.innerHTML = `
          <input class="profile-name-input" type="text" maxlength="32" spellcheck="true" aria-label="Profile name">
          <button class="profile-save" type="button" data-profile-action="save-rename" data-profile-id="${profile.id}">Save</button>
          <button class="profile-cancel" type="button" data-profile-action="cancel-edit">Cancel</button>
        `;
        editRow.querySelector(".profile-name-input").value = profile.name;
        profileMenu.appendChild(editRow);
        continue;
      }

      const row = document.createElement("div");
      row.className = "profile-row";

      const option = document.createElement("button");
      option.className = `profile-option ${profile.id === activeProfileId ? "active" : ""}`;
      option.type = "button";
      option.dataset.profileAction = "select";
      option.dataset.profileId = profile.id;
      option.textContent = profile.name;

      option.title = "Double-click to rename";
      row.append(option);

      const renameHint = document.createElement("button");
      renameHint.className = "profile-rename-hint";
      renameHint.type = "button";
      renameHint.dataset.profileAction = "rename";
      renameHint.dataset.profileId = profile.id;
      renameHint.title = "Rename profile";
      renameHint.setAttribute("aria-label", `Rename ${profile.name}`);
      renameHint.textContent = "✎";
      row.appendChild(renameHint);

      if (profiles.length > 1) {
        const deleteBtn = document.createElement("button");
        deleteBtn.className = "profile-delete";
        deleteBtn.type = "button";
        deleteBtn.dataset.profileAction = "delete";
        deleteBtn.dataset.profileId = profile.id;
        deleteBtn.title = "Delete profile";
        deleteBtn.setAttribute("aria-label", `Delete ${profile.name}`);
        deleteBtn.textContent = "×";
        row.appendChild(deleteBtn);
      }

      profileMenu.appendChild(row);
    }

    if (profileCreating) {
      const createRow = document.createElement("div");
      createRow.className = "profile-edit-row";
      createRow.innerHTML = `
        <input class="profile-name-input" type="text" maxlength="32" spellcheck="true" aria-label="New profile name">
        <button class="profile-save" type="button" data-profile-action="save-create">Save</button>
        <button class="profile-cancel" type="button" data-profile-action="cancel-edit">Cancel</button>
      `;
      createRow.querySelector(".profile-name-input").value = nextProfileName();
      profileMenu.appendChild(createRow);
    } else {
      const create = document.createElement("button");
      create.className = "profile-create";
      create.type = "button";
      create.dataset.profileAction = "create";
      create.textContent = "+ New profile";
      profileMenu.appendChild(create);
    }

    if (profileEditingId || profileCreating) {
      setTimeout(() => {
        const input = profileMenu.querySelector(".profile-name-input");
        input?.focus();
        input?.select();
      }, 0);
    }
  }

  function nextProfileName() {
    return `Mainline User ${normalizeProfiles(state.profiles).length + 1}`;
  }

  async function switchProfile(profileId) {
    if (!profileId || profileId === activeProfileId) {
      profileMenu.classList.remove("open");
      return;
    }
    profileEditingId = null;
    profileCreating = false;
    profileDeletingId = null;
    activeProfileId = profileId;
    state.activeProfileId = activeProfileId;
    activeDateKey = todayKey();
    calendarSelectedDate = null;
    calendarMonthDate = parseDateKey(todayKey());
    openId = null;
    profileMenu.classList.remove("open");
    await save();
    render();
  }

  function startRenameProfile(profileId) {
    profileEditingId = profileId;
    profileCreating = false;
    profileDeletingId = null;
    renderProfileControls();
    profileMenu.classList.add("open");
  }

  function startCreateProfile() {
    profileEditingId = null;
    profileCreating = true;
    profileDeletingId = null;
    renderProfileControls();
    profileMenu.classList.add("open");
  }

  function startDeleteProfile(profileId) {
    if (normalizeProfiles(state.profiles).length <= 1) return;
    profileEditingId = null;
    profileCreating = false;
    profileDeletingId = profileId;
    renderProfileControls();
    profileMenu.classList.add("open");
  }

  function cancelProfileEdit() {
    profileEditingId = null;
    profileCreating = false;
    profileDeletingId = null;
    renderProfileControls();
    profileMenu.classList.add("open");
  }

  async function saveRenamedProfile(profileId, rawName) {
    const profile = normalizeProfiles(state.profiles).find(item => item.id === profileId) || activeProfile();
    const cleaned = String(rawName || "").trim() || profile.name;
    state.profiles = normalizeProfiles(state.profiles).map(item =>
      item.id === profile.id ? { ...item, name: cleaned } : item
    );
    profileEditingId = null;
    profileCreating = false;
    profileDeletingId = null;
    await save();
    render();
    profileMenu.classList.add("open");
  }

  async function saveCreatedProfile(rawName) {
    const cleaned = String(rawName || "").trim() || nextProfileName();
    const profile = { id: `profile-${crypto.randomUUID()}`, name: cleaned };
    state.profiles = [...normalizeProfiles(state.profiles), profile];
    activeProfileId = profile.id;
    state.activeProfileId = activeProfileId;
    activeDateKey = todayKey();
    calendarSelectedDate = null;
    calendarMonthDate = parseDateKey(todayKey());
    openId = null;
    profileEditingId = null;
    profileCreating = false;
    profileDeletingId = null;
    profileMenu.classList.remove("open");
    await save();
    render();
  }

  async function deleteProfile(profileId) {
    const profiles = normalizeProfiles(state.profiles);
    if (profiles.length <= 1) return;

    const remainingProfiles = profiles.filter(profile => profile.id !== profileId);
    if (!remainingProfiles.length) return;

    const nextActiveId = activeProfileId === profileId ? remainingProfiles[0].id : activeProfileId;
    state.profiles = normalizeProfiles(remainingProfiles);
    activeProfileId = nextActiveId;
    state.activeProfileId = nextActiveId;
    state.mainlines = (state.mainlines || []).filter(item => item.profileId !== profileId);
    state.standaloneTodos = (state.standaloneTodos || []).filter(todo => todo.profileId !== profileId);
    state.calendarLabels = (state.calendarLabels || []).filter(label => label.profileId !== profileId);

    if (state.dailyNotes) {
      state.dailyNotes = Object.fromEntries(
        Object.entries(state.dailyNotes).filter(([key]) => !key.startsWith(`${profileId}:`))
      );
    }

    activeDateKey = todayKey();
    calendarSelectedDate = null;
    calendarMonthDate = parseDateKey(todayKey());
    openId = null;
    profileEditingId = null;
    profileCreating = false;
    profileDeletingId = null;
    profileMenu.classList.remove("open");
    await save();
    render();
  }

  function setCalendarMode(mode) {
    calendarMode = mode === "label" ? "label" : "todo";
    calendarModeTodoBtn.classList.toggle("active", calendarMode === "todo");
    calendarModeLabelBtn.classList.toggle("active", calendarMode === "label");
    calendarAddForm.classList.toggle("hidden", calendarMode !== "todo");
    calendarLabelForm.classList.toggle("hidden", calendarMode !== "label");
  }

  async function updateCalendarTodo(rowData, patch) {
    if (rowData.type === "mainline") {
      state.mainlines = state.mainlines.map(item => {
        if (item.id !== rowData.item.id) return item;
        return {
          ...item,
          steps: {
            ...item.steps,
            todayTodos: (item.steps?.todayTodos || []).map(todo =>
              todo.id === rowData.todo.id ? { ...todo, ...patch, keepBlank: false } : todo
            )
          },
          updatedAt: Date.now()
        };
      });
    } else {
      state.standaloneTodos = (state.standaloneTodos || []).map(todo =>
        todo.id === rowData.todo.id ? { ...todo, ...patch, keepBlank: false } : todo
      );
    }

    await save();
    render();
    renderCalendarPanel();
  }

  async function removeCalendarTodo(rowData) {
    if (rowData.type === "mainline") {
      await removeTodo(rowData.item.id, rowData.todo.id);
    } else {
      await removeStandaloneTodo(rowData.todo.id);
    }
    renderCalendarPanel();
  }

  async function updateCalendarLabel(labelId, patch) {
    state.calendarLabels = (state.calendarLabels || []).map(label =>
      label.id === labelId ? { ...label, ...patch } : label
    );
    await save();
    render();
    renderCalendarPanel();
  }

  async function removeCalendarLabel(labelId) {
    state.calendarLabels = (state.calendarLabels || []).filter(label => label.id !== labelId);
    await save();
    render();
    renderCalendarPanel();
  }

  function dateKeyFromDate(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }

  function parseDateKey(dateKey) {
    const [year, month, day] = String(dateKey || todayKey()).split("-").map(Number);
    return new Date(year || new Date().getFullYear(), (month || 1) - 1, day || 1);
  }

  function monthTitle(date) {
    return new Intl.DateTimeFormat(undefined, {
      month: "long",
      year: "numeric"
    }).format(date);
  }

  function calendarRowsForDate(dateKey) {
    const rows = [];

    for (const item of state.mainlines.filter(mainline => !mainline.trashed && mainline.profileId === activeProfileId)) {
      for (const todo of item.steps?.todayTodos || []) {
        if (!todo.done && todoDate(todo) === dateKey && String(todo.text || "").trim()) {
          rows.push({ type: "mainline", item, todo });
        }
      }
    }

    for (const todo of activeStandaloneTodos()) {
      if (todoDate(todo) === dateKey && String(todo.text || "").trim()) {
        rows.push({ type: "standalone", todo });
      }
    }

    return rows;
  }

  function deadlineRowsForDate(dateKey) {
    const rows = [];

    for (const item of state.mainlines.filter(mainline => !mainline.trashed && mainline.profileId === activeProfileId)) {
      for (const todo of item.steps?.todayTodos || []) {
        if (!todo.done && todo.deadlineFor === dateKey && String(todo.text || "").trim()) {
          rows.push({ type: "mainline", item, todo });
        }
      }
    }

    for (const todo of activeStandaloneTodos()) {
      if (todo.deadlineFor === dateKey && String(todo.text || "").trim()) {
        rows.push({ type: "standalone", todo });
      }
    }

    return rows;
  }

  function openCalendarDate(dateKey) {
    calendarSelectedDate = null;
    calendarMonthDate = parseDateKey(dateKey);
    activeDateKey = dateKey;
    closeCalendarPanel();
    render();
  }

  function renderCalendarMonthDetails(year, month) {
    calendarDetailToggle.textContent = calendarDetailsVisible ? "Hide details" : "Show details";
    calendarDetailToggle.classList.toggle("active", calendarDetailsVisible);
    calendarDetailToggle.setAttribute("aria-expanded", String(calendarDetailsVisible));
    calendarMonthDetails.classList.toggle("visible", calendarDetailsVisible);
    calendarMonthDetails.innerHTML = "";
    if (!calendarDetailsVisible) return;

    const totalDays = new Date(year, month + 1, 0).getDate();
    let populatedDays = 0;

    for (let dayNumber = 1; dayNumber <= totalDays; dayNumber += 1) {
      const date = new Date(year, month, dayNumber);
      const key = dateKeyFromDate(date);
      const rows = calendarRowsForDate(key);
      const specialDays = activeCalendarLabelsForDate(key)
        .filter(label => label.kind === "special");
      if (!rows.length && !specialDays.length) continue;

      populatedDays += 1;
      const dayGroup = document.createElement("div");
      dayGroup.className = "calendar-detail-day";

      const dateButton = document.createElement("button");
      dateButton.className = "calendar-detail-date";
      dateButton.type = "button";
      dateButton.textContent = new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        weekday: "short"
      }).format(date);
      dateButton.addEventListener("click", event => {
        event.preventDefault();
        openCalendarDate(key);
      });

      const items = document.createElement("div");
      items.className = "calendar-detail-items";

      for (const rowData of rows) {
        const item = document.createElement("div");
        item.className = "calendar-detail-item";
        item.innerHTML = `
          <span class="calendar-detail-dot"></span>
          <span class="calendar-detail-text"></span>
          <span class="calendar-detail-meta"></span>
        `;
        item.querySelector(".calendar-detail-text").textContent = rowData.todo.text || "";
        item.querySelector(".calendar-detail-meta").textContent = rowData.type === "mainline"
          ? (rowData.item.name || "Untitled")
          : "Quick";
        items.appendChild(item);
      }

      for (const specialDay of specialDays) {
        const item = document.createElement("div");
        item.className = "calendar-detail-item";
        item.innerHTML = `
          <span class="calendar-detail-dot"></span>
          <span class="calendar-detail-text"></span>
          <span class="calendar-detail-meta">Special</span>
        `;
        item.querySelector(".calendar-detail-dot").style.backgroundColor = specialDay.color || "#6f7f9f";
        item.querySelector(".calendar-detail-text").textContent = specialDay.text || "";
        items.appendChild(item);
      }

      dayGroup.append(dateButton, items);
      calendarMonthDetails.appendChild(dayGroup);
    }

    if (!populatedDays) {
      const empty = document.createElement("div");
      empty.className = "calendar-detail-empty";
      empty.textContent = "No todos or special days this month.";
      calendarMonthDetails.appendChild(empty);
    }
  }

  function renderCalendarPanel() {
    if (!calendarPanel.classList.contains("visible")) return;

    setCalendarMode(calendarMode);
    calendarTitle.textContent = monthTitle(calendarMonthDate);
    calendarGrid.innerHTML = "";
    calendarMainlineSelect.innerHTML = "";

    const quickOption = document.createElement("option");
    quickOption.value = "__quick__";
    quickOption.textContent = "Quick action";
    calendarMainlineSelect.appendChild(quickOption);

    for (const item of state.mainlines.filter(mainline => !mainline.trashed && mainline.profileId === activeProfileId)) {
      const option = document.createElement("option");
      option.value = item.id;
      option.textContent = item.name || "Untitled";
      calendarMainlineSelect.appendChild(option);
    }

    const year = calendarMonthDate.getFullYear();
    const month = calendarMonthDate.getMonth();
    const first = new Date(year, month, 1);
    const gridStart = new Date(year, month, 1 - first.getDay());

    for (let index = 0; index < 42; index += 1) {
      const day = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + index);
      const key = dateKeyFromDate(day);
      const rows = calendarRowsForDate(key);
      const deadlines = deadlineRowsForDate(key);
      const labels = activeCalendarLabelsForDate(key);
      const button = document.createElement("button");
      button.type = "button";
      button.className = "calendar-day";
      button.classList.toggle("other-month", day.getMonth() !== month);
      button.classList.toggle("today", key === todayKey());
      button.classList.toggle("selected", key === activeDateKey);
      button.setAttribute("aria-label", `${formatDateKey(key)} ${rows.length} actions ${deadlines.length} deadlines ${labels.length} labels`);
      button.innerHTML = `
        <span class="calendar-day-number"></span>
        <span class="calendar-day-dots"></span>
      `;
      button.querySelector(".calendar-day-number").textContent = String(day.getDate());
      const dots = button.querySelector(".calendar-day-dots");
      for (let dotIndex = 0; dotIndex < Math.min(rows.length, 3); dotIndex += 1) {
        const dot = document.createElement("span");
        dot.className = "calendar-dot";
        dots.appendChild(dot);
      }
      if (deadlines.length) {
        const dot = document.createElement("span");
        dot.className = "calendar-dot deadline";
        dots.appendChild(dot);
      }
      for (const label of labels.slice(0, 3)) {
        const dot = document.createElement("span");
        dot.className = "calendar-dot label";
        dot.style.backgroundColor = label.color || "#6f7f9f";
        dots.appendChild(dot);
      }
      button.addEventListener("click", event => {
        event.preventDefault();
        openCalendarDate(key);
      });
      calendarGrid.appendChild(button);
    }

    renderCalendarMonthDetails(year, month);
    calendarSelected.classList.add("hidden");
    return;

    if (!calendarSelectedDate) {
      calendarSelected.classList.add("hidden");
      calendarSelectedTitle.textContent = "";
      calendarDayList.innerHTML = "";
      calendarTodoText.value = "";
      calendarLabelText.value = "";
      calendarDeadlineToggle.checked = false;
      calendarDeadlineRow.classList.remove("active");
      calendarDeadlineInput.disabled = true;
      calendarDeadlineInput.value = "";
      return;
    }

    calendarSelected.classList.remove("hidden");
    calendarSelectedTitle.textContent = formatDateKey(calendarSelectedDate);
    calendarDayList.innerHTML = "";
    const selectedRows = calendarRowsForDate(calendarSelectedDate);
    const selectedDeadlines = deadlineRowsForDate(calendarSelectedDate)
      .filter(row => !selectedRows.some(item => item.todo.id === row.todo.id));
    const selectedLabels = activeCalendarLabelsForDate(calendarSelectedDate);

    if (!selectedRows.length && !selectedDeadlines.length && !selectedLabels.length) {
      const empty = document.createElement("div");
      empty.className = "calendar-day-empty";
      empty.textContent = "No items for this day.";
      calendarDayList.appendChild(empty);
    }

    for (const label of selectedLabels.slice(0, 5)) {
      const line = document.createElement("div");
      line.className = "calendar-edit-row";
      line.innerHTML = `
        <span class="calendar-edit-body">
          <span class="calendar-edit-meta">Label</span>
          <input type="text" maxlength="48" spellcheck="true">
        </span>
        <button class="calendar-edit-delete" type="button" aria-label="Delete label">×</button>
      `;
      const input = line.querySelector("input");
      input.value = label.text;
      input.addEventListener("change", () => {
        const next = input.value.trim();
        if (next) updateCalendarLabel(label.id, { text: next });
      });
      input.addEventListener("keydown", event => {
        if (event.key === "Enter") {
          event.preventDefault();
          input.blur();
        }
      });
      line.querySelector(".calendar-edit-delete").addEventListener("click", event => {
        event.preventDefault();
        removeCalendarLabel(label.id);
      });
      calendarDayList.appendChild(line);
    }

    for (const row of selectedRows.slice(0, 5)) {
      const line = document.createElement("div");
      line.className = "calendar-edit-row";
      line.innerHTML = `
        <span class="calendar-edit-body">
          <span class="calendar-edit-meta"></span>
          <textarea maxlength="300" spellcheck="true" rows="1"></textarea>
        </span>
        <button class="calendar-edit-delete" type="button" aria-label="Delete todo">×</button>
      `;
      const meta = line.querySelector(".calendar-edit-meta");
      meta.textContent = row.type === "mainline" ? (row.item.name || "Untitled") : "Quick action";
      const input = line.querySelector("textarea");
      input.value = row.todo.text || "";
      autosizeTodoField(input);
      input.addEventListener("input", () => autosizeTodoField(input));
      input.addEventListener("change", () => {
        const next = input.value.trim();
        if (next) updateCalendarTodo(row, { text: next });
      });
      line.querySelector(".calendar-edit-delete").addEventListener("click", event => {
        event.preventDefault();
        removeCalendarTodo(row);
      });
      calendarDayList.appendChild(line);
    }

    for (const row of selectedDeadlines.slice(0, 3)) {
      const line = document.createElement("div");
      line.className = "calendar-info-row deadline";
      line.innerHTML = `<span class="calendar-info-icon"></span><span></span>`;
      line.querySelector("span:last-child").textContent = row.type === "mainline"
        ? `Deadline · ${row.item.name || "Untitled"}: ${row.todo.text}`
        : `Deadline · ${row.todo.text}`;
      calendarDayList.appendChild(line);
    }

    calendarDeadlineToggle.checked = false;
    calendarDeadlineRow.classList.remove("active");
    calendarDeadlineInput.disabled = true;
    calendarDeadlineInput.value = "";
    calendarDeadlineInput.min = calendarSelectedDate;
  }

  async function addCalendarTodo() {
    if (!calendarSelectedDate) return;

    const text = calendarTodoText.value.trim();
    if (!text) {
      calendarTodoText.focus();
      return;
    }

    const deadlineFor = calendarDeadlineToggle.checked
      ? (calendarDeadlineInput.value || calendarSelectedDate)
      : "";
    const created = makeTodo(text, false, "", calendarSelectedDate, deadlineFor);

    if (calendarMainlineSelect.value && calendarMainlineSelect.value !== "__quick__") {
      const itemId = calendarMainlineSelect.value;
      state.mainlines = state.mainlines.map(old => old.id === itemId ? {
        ...old,
        steps: {
          ...old.steps,
          todayTodos: [...(old.steps.todayTodos || []), created]
        },
        updatedAt: Date.now()
      } : old);
    } else {
      state.standaloneTodos = [...(state.standaloneTodos || []), created];
    }

    calendarTodoText.value = "";
    calendarDeadlineToggle.checked = false;
    calendarDeadlineRow.classList.remove("active");
    calendarDeadlineInput.disabled = true;
    calendarDeadlineInput.value = "";
    await save();
    render();
    renderCalendarPanel();
    calendarTodoText.focus();
  }

  async function addCalendarLabel() {
    if (!calendarSelectedDate) return;

    const text = calendarLabelText.value.trim();
    if (!text) {
      calendarLabelText.focus();
      return;
    }

    const label = makeCalendarLabel(calendarSelectedDate, text, calendarLabelKind.value || "personal");
    state.calendarLabels = [...(state.calendarLabels || []), label];
    calendarLabelText.value = "";
    await save();
    render();
    renderCalendarPanel();
    calendarLabelText.focus();
  }

  function renderTodayDock() {
    todayDock.style.display = trashView ? "none" : "block";
    todayDockLabel.textContent = activeDateLabel();
    todayDockDate.textContent = formatDateKey(activeDateKey);
    todayBackBtn.classList.toggle("visible", activeDateKey !== todayKey());
    todayDockList.innerHTML = "";

    const rows = [];

    // Mainline todos stay first: Today still reads as all active mainline todos.
    for (const item of state.mainlines.filter(mainline => !mainline.trashed && mainline.profileId === activeProfileId)) {
      for (const todo of item.steps?.todayTodos || []) {
        if (todoDate(todo) === activeDateKey && String(todo.text || "").trim()) {
          rows.push({ type: "mainline", item, todo });
        }
      }
    }

    // Quick todos outside mainlines appear underneath the mainline todos.
    for (const todo of activeStandaloneTodos()) {
      if (todoDate(todo) === activeDateKey && todo.text?.trim()) {
        rows.push({ type: "standalone", todo });
      }
    }

    if (focusTodayQuickDraft && focusTodayQuickTodoId) {
      const activeDraft = activeStandaloneTodos().find(todo =>
        todo.id === focusTodayQuickTodoId
        && todoDate(todo) === activeDateKey
        && !String(todo.text || "").trim()
      );
      if (activeDraft) rows.push({ type: "standalone", todo: activeDraft });
    }

    const labelRows = activeCalendarLabelsForDate(activeDateKey);
    const deadlineInfoRows = deadlineRowsForDate(activeDateKey)
      .filter(row => todoDate(row.todo) !== activeDateKey);

    if (!rows.length && !labelRows.length && !deadlineInfoRows.length) {
      const empty = document.createElement("div");
      empty.className = "dock-empty";
      empty.textContent = activeDateKey === todayKey()
        ? "No dated to-do lines yet."
        : "No planned actions for this day.";
      todayDockList.appendChild(empty);
    }

    for (const rowData of deadlineInfoRows) {
      const row = document.createElement("div");
      row.className = "calendar-info-row deadline";
      row.innerHTML = `<span class="calendar-info-icon"></span><span></span>`;
      row.querySelector("span:last-child").textContent = rowData.type === "mainline"
        ? `Deadline · ${rowData.item.name || "Untitled"}: ${rowData.todo.text}`
        : `Deadline · ${rowData.todo.text}`;
      todayDockList.appendChild(row);
    }

    for (const rowData of rows) {
      if (rowData.type === "mainline") {
        const { item, todo } = rowData;
        const row = document.createElement("div");
        row.className = `dock-todo ${todo.done ? "done" : ""}`;
        row.dataset.itemId = item.id;
        row.dataset.todoId = todo.id;
        row.innerHTML = `
          <input type="checkbox" aria-label="Complete today's to-do">
          <span class="dock-todo-text">
            <span class="dock-todo-main">
              <span class="dock-todo-action"></span>
              <span class="dock-todo-title"></span>
            </span>
            <textarea class="dock-todo-action-input" maxlength="300" rows="1" spellcheck="true" aria-label="Edit today's mainline to-do"></textarea>
            <span class="todo-deadline"></span>
          </span>
          <button class="dock-delete" type="button" aria-label="Delete today's mainline to-do" title="Delete">×</button>
        `;
        const dockCheck = row.querySelector("input");
        const actionText = row.querySelector(".dock-todo-action");
        const actionInput = row.querySelector(".dock-todo-action-input");
        const dockDelete = row.querySelector(".dock-delete");

        dockCheck.checked = Boolean(todo.done);
        const folderLabel = row.querySelector(".dock-todo-title");
        folderLabel.textContent = item.name || "Untitled";
        folderLabel.title = item.name || "Untitled";
        row.title = item.name || "Untitled";
        updateTodoLinkView(actionText, todo.text);
        actionInput.value = todo.text || "";
        applyDeadlineText(row.querySelector(".todo-deadline"), todo);
        autosizeTodoField(actionInput);

        function openTodayMainlineTextEditor(selectText = false) {
          if (dockCheck.checked || todo.done) return;
          row.classList.add("editing-text");
          actionInput.value = actionText.textContent || "";
          autosizeTodoField(actionInput);
          if (selectText) {
            selectTodoInputText(actionInput);
          } else {
            focusTodoInput(actionInput);
          }
        }

        function syncFolderTodoField(text) {
          try {
            const selector = `.item[data-id="${item.id}"] .todo-line[data-todo-id="${todo.id}"] .todo-input`;
            const folderInput = root.querySelector(selector);
            if (folderInput) {
              folderInput.value = text;
              autosizeTodoField(folderInput);
              updateTodoLinkView(folderInput.closest(".todo-line-body")?.querySelector(".todo-link-view"), text);
            }
          } catch {
            // State is still the source of truth.
          }
        }

        dockCheck.addEventListener("click", event => {
          event.stopPropagation();
        });
        dockCheck.addEventListener("change", () => toggleTodoDone(item.id, todo.id, dockCheck.checked));

        row.addEventListener("click", event => {
          if (
            event.target === dockCheck
            || event.target.closest?.("input[type='checkbox']")
            || event.target.closest?.(".dock-delete")
            || event.target.closest?.(".todo-link")
          ) return;
          if (row.classList.contains("editing-text")) return;
          event.preventDefault();
          event.stopPropagation();
          openTodayMainlineTextEditor(false);
        });

        row.addEventListener("dblclick", event => {
          if (
            event.target === dockCheck
            || event.target.closest?.("input[type='checkbox']")
            || event.target.closest?.(".dock-delete")
            || event.target.closest?.(".todo-link")
          ) return;
          if (row.classList.contains("editing-text")) return;
          event.preventDefault();
          event.stopPropagation();
          openTodayMainlineTextEditor(false);
        });

        dockDelete.addEventListener("click", async event => {
          event.preventDefault();
          event.stopPropagation();
          await removeTodo(item.id, todo.id);
        });

        actionText.addEventListener("click", event => {
          if (handleTodoLinkClick(event)) return;
        });

        actionText.addEventListener("dblclick", event => {
          if (event.target.closest?.(".todo-link")) return;
          event.preventDefault();
          event.stopPropagation();
          openTodayMainlineTextEditor(true);
        });

        actionInput.addEventListener("dblclick", event => {
          event.preventDefault();
          event.stopPropagation();
          selectTodoInputText(actionInput);
        });

        actionInput.addEventListener("click", event => {
          event.stopPropagation();
        });

        actionInput.addEventListener("input", () => {
          autosizeTodoField(actionInput);
          const text = actionInput.value;
          updateTodoLinkView(actionText, text);

          state.mainlines = state.mainlines.map(old => {
            if (old.id !== item.id) return old;

            const currentTodo = (old.steps.todayTodos || []).find(t => t.id === todo.id);
            const completedId = currentTodo?.completedId || null;

            return {
              ...old,
              steps: {
                ...old.steps,
                completed: completedId
                  ? (old.steps.completed || []).map(doneItem => doneItem.id === completedId ? { ...doneItem, text } : doneItem)
                  : (old.steps.completed || []),
                todayTodos: (old.steps.todayTodos || []).map(t => t.id === todo.id ? { ...t, text, keepBlank: false } : t)
              },
              updatedAt: Date.now()
            };
          });

          syncFolderTodoField(text);
          scheduleAutoSave(save, 350);
        });

        actionInput.addEventListener("blur", async () => {
          row.classList.remove("editing-text");
          if (!actionInput.value.trim()) {
            await removeTodo(item.id, todo.id);
            return;
          }
          await save();
        });

        todayDockList.appendChild(row);
        continue;
      }

      const { todo } = rowData;
      const row = document.createElement("div");
      row.className = `todo-line today-quick-line ${todo.done ? "done" : ""}`;
      row.innerHTML = `
        <input class="todo-check" type="checkbox" aria-label="Complete standalone todo">
        <div class="todo-line-body">
          <span class="todo-link-view"></span>
          <textarea class="todo-input todo-textarea" maxlength="300" spellcheck="true" placeholder="Quick to-do" rows="1"></textarea>
          <span class="todo-deadline"></span>
        </div>
        <button class="line-delete" type="button" aria-label="Delete todo" title="Delete">×</button>
      `;

      const check = row.querySelector(".todo-check");
      const input = row.querySelector(".todo-input");
      const del = row.querySelector(".line-delete");

      row.dataset.todoId = todo.id;
      check.checked = Boolean(todo.done);
      input.value = todo.text || "";
      updateTodoLinkView(row.querySelector(".todo-link-view"), todo.text);
      applyDeadlineText(row.querySelector(".todo-deadline"), todo);
      autosizeTodoField(input);

      if (todo.id !== "draft") {
        input.readOnly = true;
      }

      function openQuickFreeType(activeLine) {
        todayDockList.querySelectorAll(".today-quick-line").forEach(item => {
          const isActive = item === activeLine;
          item.classList.toggle("editing", isActive);
          item.querySelectorAll(".todo-input").forEach(field => {
            field.readOnly = !isActive;
          });
        });
      }

      function ensureStandaloneTodoId() {
        let todoId = row.dataset.todoId;
        if (todoId !== "draft") return todoId;

        const created = makeTodo("", false, "", activeDateKey);
        todoId = created.id;
        row.dataset.todoId = todoId;
        state.standaloneTodos = [...(state.standaloneTodos || []), created];
        return todoId;
      }

      check.addEventListener("change", async () => {
        let todoId = row.dataset.todoId;
        if (todoId === "draft") {
          if (!input.value.trim()) {
            check.checked = false;
            return;
          }
          todoId = ensureStandaloneTodoId();
        }
        await updateStandaloneTodo(todoId, { done: check.checked });
        render();
      });

      function openQuickEditorIfAllowed(selectText = false) {
        if (check.checked || todo.done) return;
        openQuickFreeType(row);
        if (selectText) {
          selectTodoInputText(input);
        } else {
          focusTodoInput(input);
        }
      }

      row.addEventListener("click", event => {
        if (event.target.closest(".line-delete")) return;
        if (event.target === check || event.target.closest?.(".todo-check")) return;
        if (event.target.closest?.(".todo-link")) return;
        event.preventDefault();
        event.stopPropagation();
        openQuickEditorIfAllowed(false);
      });

      row.addEventListener("dblclick", event => {
        if (event.target.closest(".line-delete") || event.target === check || event.target.closest?.(".todo-check")) return;
        if (event.target.closest?.(".todo-link")) return;
        event.preventDefault();
        event.stopPropagation();
        openQuickEditorIfAllowed(false);
      });

      input.addEventListener("focus", () => {
        if (row.classList.contains("editing")) openQuickFreeType(row);
      });
      input.addEventListener("click", event => {
        event.stopPropagation();
        if (!row.classList.contains("editing")) {
          openQuickEditorIfAllowed(false);
        }
      });

      input.addEventListener("dblclick", event => {
        event.preventDefault();
        event.stopPropagation();
        openQuickEditorIfAllowed(true);
      });

      input.addEventListener("input", () => {
        autosizeTodoField(input);
        updateTodoLinkView(row.querySelector(".todo-link-view"), input.value);
        const todoId = ensureStandaloneTodoId();
        state.standaloneTodos = (state.standaloneTodos || []).map(old =>
          old.id === todoId ? { ...old, text: input.value, keepBlank: false, createdFor: activeDateKey, scheduledFor: activeDateKey } : old
        );
        scheduleAutoSave(save, 700);
      });

      row.querySelector(".todo-link-view")?.addEventListener("click", event => {
        handleTodoLinkClick(event);
      });

      let quickFinishQueued = false;
      function queueFinishQuickEditing() {
        if (quickFinishQueued) return;
        quickFinishQueued = true;
        setTimeout(async () => {
          quickFinishQueued = false;
          if (row.contains(root.activeElement)) return;

          const hasContent = Boolean(input.value.trim());

          if (row.dataset.todoId === "draft") {
            if (!hasContent) {
              if (isAddingTodoByPlus) {
                row.classList.remove("editing");
                input.readOnly = true;
                return;
              }
              row.classList.remove("editing");
              input.readOnly = false;
              return;
            }
            ensureStandaloneTodoId();
          }

          row.classList.remove("editing");
          input.readOnly = true;

          if (row.dataset.todoId !== "draft") {
            if (hasContent) {
              focusTodayQuickDraft = false;
              await save();
            } else {
              focusTodayQuickDraft = false;
              focusTodayQuickTodoId = null;
              await removeStandaloneTodo(row.dataset.todoId);
            }
          }
        }, 0);
      }

      root.addEventListener("pointerdown", event => {
        if (!row.classList.contains("editing")) return;
        if (row.contains(event.target)) return;
        queueFinishQuickEditing();
      });
      input.addEventListener("blur", queueFinishQuickEditing);
      row.addEventListener("focusout", queueFinishQuickEditing);

      del.addEventListener("click", async event => {
        event.preventDefault();
        const todoId = row.dataset.todoId;
        if (todoId === "draft") {
          row.classList.remove("editing");
          input.value = "";
          return;
        }
        await removeStandaloneTodo(todoId);
      });

      todayDockList.appendChild(row);
    }

    const specialDayZone = document.createElement("div");
    specialDayZone.className = "special-day-zone";
    const specialDayColors = ["#b45f6a", "#7667a8", "#6f7f9f", "#5d7f73", "#b7791f"];

    for (const label of labelRows) {
      const row = document.createElement("div");
      row.className = "special-day-row";
      row.dataset.specialDayId = label.id;
      row.style.setProperty("--special-color", label.color || "#6f7f9f");
      row.innerHTML = `
        <span class="special-day-color-wrap">
          <button class="special-day-color" type="button" aria-label="Choose special day color" aria-expanded="false"></button>
          <span class="special-day-palette"></span>
        </span>
        <input class="special-day-input" type="text" maxlength="48" spellcheck="true" placeholder="Type a name..." readonly aria-label="Edit special day">
        <button class="special-day-delete" type="button" aria-label="Delete special day" title="Delete">×</button>
      `;
      const colorWrap = row.querySelector(".special-day-color-wrap");
      const color = row.querySelector(".special-day-color");
      const palette = row.querySelector(".special-day-palette");
      const input = row.querySelector(".special-day-input");
      const del = row.querySelector(".special-day-delete");
      input.value = label.text || "";

      colorWrap.addEventListener("pointerdown", event => {
        event.preventDefault();
        event.stopPropagation();
      });

      for (const value of specialDayColors) {
        const swatch = document.createElement("button");
        swatch.className = `special-day-swatch ${value === (label.color || "#6f7f9f") ? "active" : ""}`;
        swatch.type = "button";
        swatch.style.setProperty("--swatch-color", value);
        swatch.setAttribute("aria-label", `Use color ${value}`);
        swatch.addEventListener("click", async event => {
          event.preventDefault();
          event.stopPropagation();
          row.style.setProperty("--special-color", value);
          palette.querySelectorAll(".special-day-swatch").forEach(option => {
            option.classList.toggle("active", option === swatch);
          });
          colorWrap.classList.remove("open");
          color.setAttribute("aria-expanded", "false");
          const text = input.value.trim();
          state.calendarLabels = (state.calendarLabels || []).map(item =>
            item.id === label.id
              ? { ...item, color: value, kind: "special", ...(text ? { text } : {}) }
              : item
          );
          await save();
          renderCalendarPanel();
        });
        palette.appendChild(swatch);
      }

      color.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        if (!input.readOnly) {
          const text = input.value.trim();
          if (text) {
            state.calendarLabels = (state.calendarLabels || []).map(item =>
              item.id === label.id ? { ...item, text, kind: "special" } : item
            );
            scheduleAutoSave(save, 350);
          }
        }
        const isOpen = colorWrap.classList.toggle("open");
        color.setAttribute("aria-expanded", String(isOpen));
      });

      function editSpecialDay() {
        row.classList.add("editing");
        input.readOnly = false;
        input.focus();
        input.select();
      }

      input.addEventListener("click", event => {
        event.stopPropagation();
        if (input.readOnly) editSpecialDay();
      });

      input.addEventListener("keydown", event => {
        event.stopPropagation();
        if (event.key === "Enter") {
          event.preventDefault();
          input.blur();
        } else if (event.key === "Escape") {
          event.preventDefault();
          input.value = label.text || "";
          input.readOnly = true;
          row.classList.remove("editing");
          input.blur();
        }
      });

      input.addEventListener("blur", async () => {
        if (input.readOnly) return;
        input.readOnly = true;
        row.classList.remove("editing");
        const next = input.value.trim();
        if (!next) {
          await removeCalendarLabel(label.id);
          return;
        }
        await updateCalendarLabel(label.id, { text: next, kind: "special" });
      });

      del.addEventListener("click", async event => {
        event.preventDefault();
        event.stopPropagation();
        await removeCalendarLabel(label.id);
      });

      specialDayZone.appendChild(row);
    }

    const addSpecialDayRow = document.createElement("button");
    addSpecialDayRow.className = "special-day-add-row";
    addSpecialDayRow.type = "button";
    addSpecialDayRow.textContent = "+ Special day";
    addSpecialDayRow.addEventListener("click", async event => {
      event.preventDefault();
      event.stopPropagation();
      const created = makeCalendarLabel(activeDateKey, "Special day", "special", "#b45f6a");
      state.calendarLabels = [...(state.calendarLabels || []), created];
      await save();
      renderTodayDock();
      setTimeout(() => {
        const input = todayDockList.querySelector(`.special-day-row[data-special-day-id="${created.id}"] .special-day-input`);
        if (input) {
          input.closest(".special-day-row")?.classList.add("editing");
          input.value = "";
          input.readOnly = false;
          input.focus();
        }
      }, 0);
    });
    specialDayZone.appendChild(addSpecialDayRow);

    const addQuickRow = document.createElement("div");
    addQuickRow.className = "add-todo-row today-add-row";
    addQuickRow.innerHTML = `
      <button class="add-todo-button" type="button" aria-label="Add quick to-do">+</button>
      <span class="add-todo-label">Add quick action</span>
      <span></span>
    `;
    async function handleAddQuickTodo(event) {
      event.preventDefault();
      event.stopPropagation();
      isAddingTodoByPlus = true;
      await createOrFocusStandaloneTodo();
      setTimeout(() => { isAddingTodoByPlus = false; }, 120);
    }
    addQuickRow.addEventListener("click", handleAddQuickTodo);
    addQuickRow.querySelector(".add-todo-button")?.addEventListener("click", handleAddQuickTodo);
    todayDockList.appendChild(addQuickRow);
    todayDockList.appendChild(specialDayZone);

    if (focusTodayQuickDraft) {
      focusTodayQuickDraft = false;
      setTimeout(() => {
        const target = [...todayDockList.querySelectorAll(".today-quick-line")]
          .find(row => row.dataset.todoId === focusTodayQuickTodoId);
        const input = target?.querySelector(".todo-input")
          || [...todayDockList.querySelectorAll(".today-quick-line .todo-input")].find(input => !input.value.trim());
        if (target) {
          target.classList.add("editing");
          target.querySelectorAll(".todo-input").forEach(field => { field.readOnly = false; });
        }
        focusTodoInput(input);
        input?.scrollIntoView({ block: "nearest" });
        try { todayDock.scrollTop = todayDock.scrollHeight; } catch {}
        focusTodayQuickTodoId = null;
      }, 0);
    }
  }

  function render() {
    updateCollapsedUI();
    renderProfileControls();
    list.innerHTML = "";
    panel.classList.toggle("trash-view", trashView);
    trashBtn.classList.toggle("active", trashView);
    addBtn.style.display = trashView ? "none" : "grid";

    for (const item of items()) {
      const el = document.createElement("article");
      el.className = "item";
      el.dataset.id = item.id;
      el.draggable = !trashView;
      el.style.setProperty("--item-color", DEFAULT_COLOR);

      if (openId === item.id) el.classList.add("open");

      el.innerHTML = `
        <div class="row" role="button" tabindex="0" aria-label="Open mainline">
          <span class="folder-wrap" title="Mainline folder">
            <svg class="folder-icon" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M3.5 7.5a2 2 0 0 1 2-2h4.1l1.7 2H18.5a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-9Z"></path>
              <path d="M3.5 9h17"></path>
            </svg>
          </span>
          <span class="title-cell">
            <span class="title"></span>
            <input class="title-inline-input" type="text" maxlength="40" spellcheck="true" aria-label="Edit mainline title">
          </span>
          <button class="row-trash" type="button" aria-label="Move mainline to Trash" title="Move to Trash">×</button>
          <span class="chev">›</span>
        </div>

        <form class="editor">
          <div class="title-edit-section">
            <div class="title-actions">
              <button class="recent-toggle" type="button">Review</button>
              <button class="import-list" type="button" aria-expanded="false">Import list</button>
            </div>
          </div>

          <button class="recover" type="button">Recover</button>

          <div class="step-group">
            <div class="completed-list" aria-label="Review earlier plans and completed actions"></div>

            <div class="date-block">
              <div class="import-box">
                <textarea class="import-textarea" name="importText" spellcheck="true" placeholder="Paste one to-do per line. Bullets, numbers, and checkboxes are okay."></textarea>
                <div class="import-actions">
                  <button class="import-cancel" type="button">Cancel</button>
                  <button class="import-apply" type="button">Import</button>
                </div>
              </div>
              <div class="today-lines" aria-label="Current to-do lines"></div>
            </div>


          </div>
        </form>
      `;

      const titleEl = el.querySelector(".title");
      titleEl.textContent = item.name || "Untitled";

      const rowButton = el.querySelector(".row");
      const rowTrashBtn = el.querySelector(".row-trash");
      const form = el.querySelector("form");
      const steps = item.steps || makeSteps();
      const completedList = form.querySelector(".completed-list");
      const recentToggleBtn = form.querySelector(".recent-toggle");
      const titleEditInput = rowButton.querySelector(".title-inline-input");
      const recoverBtn = form.querySelector(".recover");
      const importListBtn = form.querySelector(".import-list");
      const importBox = form.querySelector(".import-box");
      const importText = form.elements.importText;
      const importApplyBtn = form.querySelector(".import-apply");
      const importCancelBtn = form.querySelector(".import-cancel");
      const todayLines = form.querySelector(".today-lines");
      let titleClickTimer = null;

      titleEditInput.value = item.name || "Untitled";
      renderReview(completedList, item, item.id);
      completedList.classList.toggle("visible", recentOpenIds.has(item.id));
      recentToggleBtn.classList.toggle("active", recentOpenIds.has(item.id));

      function renderTodoLines() {
        todayLines.innerHTML = "";
        const storedTodos = findMainline(item.id)?.steps?.todayTodos || [];
        const displayTodos = storedTodos
          .filter(todo => todoDate(todo) === activeDateKey)
          .filter(todo => String(todo.text || "").trim() || todo.keepBlank);

        function openFreeTypeFor(activeLine) {
          const activeCheckbox = activeLine?.querySelector?.(".todo-check");
          if (activeCheckbox?.checked || activeLine?.classList?.contains("done")) return;

          todayLines.querySelectorAll(".todo-line").forEach(row => {
            const isActive = row === activeLine;
            row.classList.toggle("editing", isActive);
            row.querySelectorAll(".todo-input").forEach(field => {
              field.readOnly = !isActive;
            });
          });
        }

        for (const todo of displayTodos) {
          const line = document.createElement("div");
          line.className = `todo-line ${todo.done ? "done" : ""}`;
          line.dataset.todoId = todo.id;
          line.innerHTML = `
            <input class="todo-check" type="checkbox" aria-label="Complete this line">
            <div class="todo-line-body">
              <span class="todo-link-view"></span>
              <textarea class="todo-input todo-textarea" maxlength="300" spellcheck="true" placeholder="Current to-do" rows="1"></textarea>
              <span class="todo-deadline"></span>
            </div>
            <button class="line-delete" type="button" aria-label="Delete line" title="Delete">×</button>
          `;
          const checkbox = line.querySelector(".todo-check");
          const input = line.querySelector(".todo-input");
          const deleteBtn = line.querySelector(".line-delete");

          input.value = todo.text || "";
          updateTodoLinkView(line.querySelector(".todo-link-view"), todo.text);
          applyDeadlineText(line.querySelector(".todo-deadline"), todo);
          autosizeTodoField(input);
          checkbox.checked = Boolean(todo.done);

          if (todo.id !== "draft") {
            input.readOnly = true;
          }

          function openFolderEditorIfAllowed(selectText = false) {
            if (checkbox?.checked || todo.done) return;
            openFreeTypeFor(line);
            if (selectText) {
              selectTodoInputText(input);
            } else {
              focusTodoInput(input);
            }
          }

          line.addEventListener("click", event => {
            if (event.target.closest(".line-delete") || event.target.closest(".todo-check")) return;
            if (event.target.closest?.(".todo-link")) return;
            event.preventDefault();
            event.stopPropagation();
            openFolderEditorIfAllowed(false);
          });

          line.addEventListener("dblclick", event => {
            if (event.target.closest(".line-delete") || event.target.closest(".todo-check")) return;
            if (event.target.closest?.(".todo-link")) return;
            event.preventDefault();
            event.stopPropagation();
            openFolderEditorIfAllowed(false);
          });

          input.addEventListener("focus", () => {
            if (line.classList.contains("editing")) openFreeTypeFor(line);
          });

          input.addEventListener("click", event => {
            event.stopPropagation();
            if (!line.classList.contains("editing")) {
              openFolderEditorIfAllowed(false);
            }
          });

          input.addEventListener("dblclick", event => {
            event.preventDefault();
            event.stopPropagation();
            openFolderEditorIfAllowed(true);
          });

          function ensureTodoId() {
            let todoId = line.dataset.todoId;
            if (todoId !== "draft") return todoId;

            const created = makeTodo("", false, "", activeDateKey);
            todoId = created.id;
            line.dataset.todoId = todoId;

            state.mainlines = state.mainlines.map(old => {
              if (old.id !== item.id) return old;
              return {
                ...old,
                steps: {
                  ...old.steps,
                  todayTodos: [...(old.steps.todayTodos || []), created]
                },
                updatedAt: Date.now()
              };
            });

            return todoId;
          }

          input.addEventListener("input", () => {
            openFreeTypeFor(line);
            autosizeTodoField(input);
            updateTodoLinkView(line.querySelector(".todo-link-view"), input.value);
            const todoId = ensureTodoId();
            const text = input.value;

            state.mainlines = state.mainlines.map(old => {
              if (old.id !== item.id) return old;

              const currentTodo = (old.steps.todayTodos || []).find(t => t.id === todoId);
              const completedId = currentTodo?.completedId || null;

              return {
                ...old,
                steps: {
                  ...old.steps,
                  completed: completedId
                    ? (old.steps.completed || []).map(doneItem => doneItem.id === completedId ? { ...doneItem, text } : doneItem)
                    : (old.steps.completed || []),
                  todayTodos: (old.steps.todayTodos || []).map(t => t.id === todoId ? { ...t, text, keepBlank: false } : t)
                },
                updatedAt: Date.now()
              };
            });

            renderTodayDock();
            scheduleAutoSave(save, 350);
          });

          input.addEventListener("blur", () => save());

          line.querySelector(".todo-link-view")?.addEventListener("click", event => {
            handleTodoLinkClick(event);
          });

          checkbox.addEventListener("change", async () => {
            let todoId = line.dataset.todoId;
            if (todoId === "draft") {
              if (!input.value.trim()) {
                checkbox.checked = false;
                return;
              }
              todoId = ensureTodoId();
            }

            if (checkbox.checked) {
              line.classList.remove("editing");
              input.readOnly = true;
            }

            await toggleTodoDone(item.id, todoId, checkbox.checked);
          });

          line.addEventListener("focusout", () => {
            setTimeout(async () => {
              if (line.contains(root.activeElement)) return;

              const todoId = line.dataset.todoId;
              const hasContent = Boolean(input.value.trim());

              if (todoId === "draft") {
                if (!hasContent) {
                  if (isAddingTodoByPlus) {
                    line.classList.remove("editing");
                    input.readOnly = true;
                    return;
                  }
                  line.classList.remove("editing");
                  input.readOnly = false;
                  return;
                }
                ensureTodoId();
              }

              line.classList.remove("editing");
              input.readOnly = true;

              if (line.dataset.todoId !== "draft") {
                if (hasContent) {
                  await save();
                  renderTodayDock();
                } else if (todo.keepBlank) {
                  await save();
                  renderTodayDock();
                } else {
                  await removeTodo(item.id, line.dataset.todoId);
                }
              }
            }, 0);
          });

          deleteBtn.addEventListener("click", async event => {
            event.preventDefault();
            await removeTodo(item.id, line.dataset.todoId);
          });

          todayLines.appendChild(line);
        }

        const addRow = document.createElement("div");
        addRow.className = "add-todo-row";
        addRow.innerHTML = `
          <button class="add-todo-button" type="button" aria-label="Add current to-do">+</button>
          <span class="add-todo-label">Add action</span>
          <span></span>
        `;
        async function handleAddCurrentTodo(event) {
          event.preventDefault();
          event.stopPropagation();
          isAddingTodoByPlus = true;
          await createOrFocusMainlineTodo(item.id);
          setTimeout(() => { isAddingTodoByPlus = false; }, 120);
        }
        addRow.addEventListener("click", handleAddCurrentTodo);
        addRow.querySelector(".add-todo-button")?.addEventListener("click", handleAddCurrentTodo);
        todayLines.appendChild(addRow);
      }

      renderTodoLines();

      if (focusBlankForItemId === item.id) {
        const blankLine = [...todayLines.querySelectorAll(".todo-line")].find(row =>
          row.dataset.todoId === focusBlankTodoId || !row.querySelector(".todo-input")?.value.trim()
        );
        if (blankLine) {
          blankLine.classList.add("editing");
          blankLine.querySelectorAll(".todo-input").forEach(field => { field.readOnly = false; });
          focusTodoInput(blankLine.querySelector(".todo-input"));
        }
        focusBlankForItemId = null;
        focusBlankTodoId = null;
      }

      if (focusTitleForItemId === item.id) {
        openTitleEditor();
        focusTitleForItemId = null;
      }

      form.addEventListener("click", event => event.stopPropagation());
      form.addEventListener("keydown", event => event.stopPropagation());
      recoverBtn.style.display = trashView ? "inline" : "none";
      rowTrashBtn.style.display = trashView ? "none" : "grid";

      if (trashView) {
        for (const c of form.querySelectorAll("input, textarea, button")) {
          if (!c.classList.contains("recover")) c.disabled = true;
        }
        el.draggable = false;
      }

      async function saveInlineTitle() {
        const nextName = titleEditInput.value.trim() || "Untitled";
        titleEditInput.value = nextName;
        titleEl.textContent = nextName;
        await updateItem(item.id, { name: nextName });
        renderTodayDock();
      }

      function openTitleEditor() {
        if (titleClickTimer) {
          clearTimeout(titleClickTimer);
          titleClickTimer = null;
        }
        if (trashView) return;
        rowButton.classList.add("editing-title");
        titleEditInput.value = titleEl.textContent || "Untitled";
        setTimeout(() => {
          titleEditInput.focus();
          titleEditInput.select();
        }, 0);
      }

      recentToggleBtn.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        if (recentOpenIds.has(item.id)) {
          recentOpenIds.delete(item.id);
        } else {
          recentOpenIds.add(item.id);
        }
        completedList.classList.toggle("visible", recentOpenIds.has(item.id));
        recentToggleBtn.classList.toggle("active", recentOpenIds.has(item.id));
      });

      rowTrashBtn.addEventListener("click", async event => {
        event.preventDefault();
        event.stopPropagation();
        await moveMainlineToTrash(item.id);
      });

      titleEl.addEventListener("dblclick", event => {
        event.preventDefault();
        event.stopPropagation();
        openTitleEditor();
      });

      titleEditInput.addEventListener("dblclick", event => {
        event.preventDefault();
        event.stopPropagation();
        titleEditInput.select();
      });

      titleEditInput.addEventListener("keydown", async event => {
        event.stopPropagation();
        if (event.key === "Enter") {
          if (event.isComposing || event.keyCode === 229) return;
          event.preventDefault();
          await saveInlineTitle();
          rowButton.classList.remove("editing-title");
          titleEditInput.blur();
        } else if (event.key === "Escape") {
          event.preventDefault();
          titleEditInput.value = titleEl.textContent || "Untitled";
          rowButton.classList.remove("editing-title");
          titleEditInput.blur();
        }
      });

      titleEditInput.addEventListener("click", event => {
        event.stopPropagation();
      });

      titleEditInput.addEventListener("blur", async () => {
        if (!rowButton.classList.contains("editing-title")) return;
        await saveInlineTitle();
        rowButton.classList.remove("editing-title");
      });

      recoverBtn.addEventListener("click", async event => {
        event.preventDefault();
        state.mainlines = state.mainlines.map(old => old.id === item.id ? {
          ...old,
          trashed: false,
          deletedAt: null,
          updatedAt: Date.now()
        } : old);
        openId = null;
        await save();
        render();
      });

      importListBtn.addEventListener("click", event => {
        event.preventDefault();
        const isVisible = importBox.classList.toggle("visible");
        importListBtn.classList.toggle("active", isVisible);
        importListBtn.setAttribute("aria-expanded", String(isVisible));
        if (isVisible) importText.focus();
      });

      importCancelBtn.addEventListener("click", event => {
        event.preventDefault();
        importText.value = "";
        importBox.classList.remove("visible");
        importListBtn.classList.remove("active");
        importListBtn.setAttribute("aria-expanded", "false");
      });

      importApplyBtn.addEventListener("click", async event => {
        event.preventDefault();
        const imported = parseImportedTodos(importText.value);
        if (!imported.length) {
          importText.focus();
          return;
        }

        state.mainlines = state.mainlines.map(old => {
          if (old.id !== item.id) return old;

          const existingTodos = old.steps.todayTodos || [];
          const cleanedTodos = existingTodos.filter(todo => {
            const isTodayBlank = !todo.done
              && todoDate(todo) === activeDateKey
              && !String(todo.text || "").trim()
              && !String(todo.freeType || "").trim();
            return !isTodayBlank;
          });

          return {
            ...old,
            steps: {
              ...old.steps,
              todayTodos: [
                ...cleanedTodos,
                ...imported.map(text => makeTodo(text, false, "", activeDateKey))
              ]
            },
            updatedAt: Date.now()
          };
        });

        importText.value = "";
        importBox.classList.remove("visible");
        importListBtn.classList.remove("active");
        importListBtn.setAttribute("aria-expanded", "false");
        await save();
        render();
      });

      rowButton.addEventListener("click", event => {
        if (event.target?.closest?.(".title-inline-input")) return;
        const toggleOpen = () => {
          openId = openId === item.id ? null : item.id;
          render();
        };

        if (event.target?.closest?.(".title")) {
          if (event.detail > 1) return;
          if (titleClickTimer) clearTimeout(titleClickTimer);
          titleClickTimer = setTimeout(() => {
            titleClickTimer = null;
            toggleOpen();
          }, 180);
          return;
        }

        toggleOpen();
      });

      rowButton.addEventListener("keydown", event => {
        if (event.target?.closest?.(".title-inline-input")) return;
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          openId = openId === item.id ? null : item.id;
          render();
        }
      });

      el.addEventListener("dragstart", event => {
        if (trashView) return;
        if (event.target.closest("form") || event.target.closest(".title-inline-input")) {
          event.preventDefault();
          return;
        }
        draggedMainlineId = item.id;
        el.classList.add("dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", item.id);
      });

      el.addEventListener("dragend", () => {
        draggedMainlineId = null;
        el.classList.remove("dragging");
        list.querySelectorAll(".item").forEach(child => child.classList.remove("drop-before", "drop-after"));
      });

      el.addEventListener("dragover", event => {
        if (trashView || !draggedMainlineId || draggedMainlineId === item.id) return;
        event.preventDefault();
        const rect = el.getBoundingClientRect();
        const after = event.clientY > rect.top + rect.height / 2;
        el.classList.toggle("drop-before", !after);
        el.classList.toggle("drop-after", after);
      });

      el.addEventListener("dragleave", () => {
        el.classList.remove("drop-before", "drop-after");
      });

      el.addEventListener("drop", async event => {
        if (trashView || !draggedMainlineId || draggedMainlineId === item.id) return;
        event.preventDefault();
        const rect = el.getBoundingClientRect();
        const after = event.clientY > rect.top + rect.height / 2;
        await reorderMainlines(draggedMainlineId, item.id, after);
      });

      list.appendChild(el);
    }

    renderTodayDock();
    if (dailyNotePanel.classList.contains("visible")) loadDailyNote();
    renderCalendarPanel();
    requestAnimationFrame(autosizeAllTodoFields);
  }

  function buildPlanText() {
    const lines = [];
    lines.push("MAINLINE PLAN");
    lines.push(`Exported: ${formatToday()}`);
    lines.push("");

    for (const item of state.mainlines.filter(mainline => !mainline.trashed)) {
      const steps = item.steps || makeSteps();
      lines.push(`## ${item.name || "Untitled"}`);

      const todos = steps.todayTodos || [];
      lines.push("");
      lines.push("Checklist:");
      if (!todos.length) {
        lines.push("- No current checklist lines.");
      } else {
        for (const todo of todos) {
          if (!todo.text && !todo.freeType) continue;
          lines.push(`- [${todo.done ? "x" : " "}] ${todo.text || "(blank)"}`);
          if (todoDate(todo) !== todayKey()) lines.push(`  Scheduled: ${formatDateKey(todoDate(todo))}`);
          if (todo.deadlineFor) lines.push(`  Deadline: ${formatDateKey(todo.deadlineFor)}`);
          if (todo.freeType) lines.push(`  Free type: ${todo.freeType}`);
        }
      }

      const completed = steps.completed || [];
      lines.push("");
      lines.push("Completed history:");
      if (!completed.length) {
        lines.push("- No completed history.");
      } else {
        for (const done of completed) {
          lines.push(`- [x] ${formatDoneDate(done.doneAt)} — ${done.text}`);
          const freeType = getCompletedFreeType(done);
          if (freeType) lines.push(`  Free type: ${freeType}`);
        }
      }

      lines.push("");
    }

    return lines.join("\\n");
  }

  todayDock.addEventListener("wheel", event => {
    const canScroll = todayDock.scrollHeight > todayDock.clientHeight + 1;
    if (!canScroll) return;

    const atTop = todayDock.scrollTop <= 0;
    const atBottom = todayDock.scrollTop + todayDock.clientHeight >= todayDock.scrollHeight - 1;
    const goingUp = event.deltaY < 0;
    const goingDown = event.deltaY > 0;

    if ((goingUp && atTop) || (goingDown && atBottom)) {
      event.stopPropagation();
      return;
    }

    todayDock.scrollTop += event.deltaY;
    event.preventDefault();
    event.stopPropagation();
  }, { passive: false });

  function loadDailyNote() {
    state.dailyNotes = state.dailyNotes || {};
    dailyNoteDate.textContent = formatDateKey(activeDateKey);
    dailyNoteTextarea.value = state.dailyNotes[dailyNoteKey()] || "";
  }

  async function saveDailyNote() {
    state.dailyNotes = state.dailyNotes || {};
    state.dailyNotes[dailyNoteKey()] = dailyNoteTextarea.value;
    await save();
  }

  async function closeDailyNotePanel() {
    if (!dailyNotePanel.classList.contains("visible")) return;
    await saveDailyNote();
    dailyNotePanel.classList.remove("visible");
    dailyNoteButton.classList.remove("active");
  }

  function closeCalendarPanel() {
    if (!calendarPanel.classList.contains("visible")) return;
    calendarPanel.classList.remove("visible");
    calendarButton.classList.remove("active");
  }

  calendarButton.addEventListener("click", async event => {
    event.preventDefault();
    event.stopPropagation();
    await closeDailyNotePanel();
    calendarPanel.classList.toggle("visible");
    calendarButton.classList.toggle("active", calendarPanel.classList.contains("visible"));
    if (calendarPanel.classList.contains("visible")) {
      calendarSelectedDate = null;
      calendarMonthDate = parseDateKey(activeDateKey || todayKey());
      renderCalendarPanel();
    }
  });

  calendarPanel.addEventListener("click", event => {
    event.stopPropagation();
  });

  calendarCloseBtn.addEventListener("click", event => {
    event.preventDefault();
    closeCalendarPanel();
  });

  calendarPrevBtn.addEventListener("click", event => {
    event.preventDefault();
    calendarMonthDate = new Date(calendarMonthDate.getFullYear(), calendarMonthDate.getMonth() - 1, 1);
    calendarSelectedDate = null;
    renderCalendarPanel();
  });

  calendarNextBtn.addEventListener("click", event => {
    event.preventDefault();
    calendarMonthDate = new Date(calendarMonthDate.getFullYear(), calendarMonthDate.getMonth() + 1, 1);
    calendarSelectedDate = null;
    renderCalendarPanel();
  });

  calendarDetailToggle.addEventListener("click", event => {
    event.preventDefault();
    calendarDetailsVisible = !calendarDetailsVisible;
    state.calendarDetailsVisible = calendarDetailsVisible;
    scheduleAutoSave(save, 200);
    renderCalendarPanel();
  });

  calendarAddBtn.addEventListener("click", event => {
    event.preventDefault();
    addCalendarTodo();
  });

  calendarModeTodoBtn.addEventListener("click", event => {
    event.preventDefault();
    setCalendarMode("todo");
    calendarTodoText.focus();
  });

  calendarModeLabelBtn.addEventListener("click", event => {
    event.preventDefault();
    setCalendarMode("label");
    calendarLabelText.focus();
  });

  calendarLabelAddBtn.addEventListener("click", event => {
    event.preventDefault();
    addCalendarLabel();
  });

  calendarLabelText.addEventListener("keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      addCalendarLabel();
    }
  });

  calendarDeadlineToggle.addEventListener("change", () => {
    if (!calendarSelectedDate) {
      calendarDeadlineToggle.checked = false;
      calendarDeadlineRow.classList.remove("active");
      calendarDeadlineInput.disabled = true;
      calendarDeadlineInput.value = "";
      return;
    }

    calendarDeadlineRow.classList.toggle("active", calendarDeadlineToggle.checked);
    calendarDeadlineInput.disabled = !calendarDeadlineToggle.checked;
    if (calendarDeadlineToggle.checked) {
      calendarDeadlineInput.min = calendarSelectedDate;
      calendarDeadlineInput.value = calendarDeadlineInput.value || calendarSelectedDate;
      setTimeout(() => calendarDeadlineInput.focus(), 0);
    } else {
      calendarDeadlineInput.value = "";
    }
  });

  calendarTodoText.addEventListener("keydown", event => {
    if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
      event.preventDefault();
      addCalendarTodo();
    }
  });

  todayBackBtn.addEventListener("click", event => {
    event.preventDefault();
    activeDateKey = todayKey();
    calendarSelectedDate = null;
    calendarMonthDate = parseDateKey(activeDateKey);
    render();
  });

  profilePill.addEventListener("click", event => {
    event.preventDefault();
    event.stopPropagation();
    profileMenu.classList.toggle("open");
    if (!profileMenu.classList.contains("open")) {
      profileEditingId = null;
      profileCreating = false;
      profileDeletingId = null;
      renderProfileControls();
    }
  });

  profileMenu.addEventListener("click", async event => {
    event.preventDefault();
    event.stopPropagation();
    const button = event.target?.closest?.("[data-profile-action]");
    if (!button) return;

    const action = button.dataset.profileAction;
    const profileId = button.dataset.profileId;
    if (action === "select") {
      if (event.detail > 1) return;
      if (profileClickTimer) clearTimeout(profileClickTimer);
      profileClickTimer = setTimeout(() => {
        profileClickTimer = null;
        switchProfile(profileId);
      }, 180);
    } else if (action === "rename") {
      startRenameProfile(profileId);
    } else if (action === "save-rename") {
      const input = button.closest(".profile-edit-row")?.querySelector(".profile-name-input");
      await saveRenamedProfile(profileId, input?.value || "");
    } else if (action === "create") {
      startCreateProfile();
    } else if (action === "save-create") {
      const input = button.closest(".profile-edit-row")?.querySelector(".profile-name-input");
      await saveCreatedProfile(input?.value || "");
    } else if (action === "delete") {
      startDeleteProfile(profileId);
    } else if (action === "confirm-delete") {
      await deleteProfile(profileId);
    } else if (action === "cancel-edit") {
      cancelProfileEdit();
    }
  });

  profileMenu.addEventListener("dblclick", event => {
    const option = event.target?.closest?.(".profile-option");
    if (!option) return;
    event.preventDefault();
    event.stopPropagation();
    if (profileClickTimer) {
      clearTimeout(profileClickTimer);
      profileClickTimer = null;
    }
    startRenameProfile(option.dataset.profileId);
  });

  profileMenu.addEventListener("keydown", async event => {
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      cancelProfileEdit();
      return;
    }

    if (!event.target?.classList?.contains("profile-name-input")) return;

    if (event.key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
      if (profileEditingId) {
        await saveRenamedProfile(profileEditingId, event.target.value);
      } else if (profileCreating) {
        await saveCreatedProfile(event.target.value);
      }
    }
  });

  dailyNoteButton.addEventListener("click", event => {
    event.preventDefault();
    event.stopPropagation();
    closeCalendarPanel();
    loadDailyNote();
    dailyNotePanel.classList.toggle("visible");
    dailyNoteButton.classList.toggle("active", dailyNotePanel.classList.contains("visible"));
    if (dailyNotePanel.classList.contains("visible")) {
      setTimeout(() => dailyNoteTextarea.focus(), 0);
    }
  });

  dailyNotePanel.addEventListener("click", event => {
    event.stopPropagation();
  });

  root.addEventListener("click", event => {
    const target = event.target;
    if (profileMenu.classList.contains("open") && !target?.closest?.(".profile-controls")) {
      profileMenu.classList.remove("open");
      profileEditingId = null;
      profileCreating = false;
      profileDeletingId = null;
      renderProfileControls();
    }
    if (dailyNotePanel.classList.contains("visible")) {
      if (!target?.closest?.(".daily-note-panel") && !target?.closest?.(".daily-note-button")) {
        closeDailyNotePanel();
      }
    }
    if (calendarPanel.classList.contains("visible")) {
      if (!target?.closest?.(".calendar-panel") && !target?.closest?.(".calendar-button")) {
        closeCalendarPanel();
      }
    }
  }, true);

  dailyNoteTextarea.addEventListener("input", () => {
    state.dailyNotes = state.dailyNotes || {};
    state.dailyNotes[dailyNoteKey()] = dailyNoteTextarea.value;
    scheduleAutoSave(save, 600);
  });

  dailyNoteTextarea.addEventListener("blur", () => saveDailyNote());

  addBtn.addEventListener("click", async () => {
    const item = {
      id: crypto.randomUUID(),
      name: "New mainline",
      steps: makeSteps([], "", []),
      color: DEFAULT_COLOR,
      profileId: activeProfileId,
      trashed: false,
      updatedAt: Date.now()
    };
    state.mainlines = [...state.mainlines, item];
    openId = item.id;
    focusTitleForItemId = item.id;
    trashView = false;
    await save();
    render();
  });

  trashBtn.addEventListener("click", () => {
    trashView = !trashView;
    openId = null;
    render();
  });

  trashBtn.addEventListener("dragover", event => {
    if (!draggedMainlineId || trashView) return;
    event.preventDefault();
    trashBtn.classList.add("drag-over");
    const dragged = state.mainlines.find(item => item.id === draggedMainlineId);
    if (dragged) trashBtn.style.setProperty("--drag-color", dragged.color || DEFAULT_COLOR);
  });

  trashBtn.addEventListener("dragleave", () => {
    trashBtn.classList.remove("drag-over");
  });

  trashBtn.addEventListener("drop", async event => {
    if (!draggedMainlineId || trashView) return;
    event.preventDefault();
    trashBtn.classList.remove("drag-over");
    await moveMainlineToTrash(draggedMainlineId);
  });

  foldToggle.addEventListener("click", async () => {
    isCollapsed = !isCollapsed;
    updateCollapsedUI();
    await save();
    await saveLayoutOnly();
  });

  try {
    chrome.runtime.onMessage.addListener((message) => {
      if (message && message.type === "MAINLINE_REMOVE_PANEL") {
        document.getElementById(HOST_ID)?.remove();
      } else if (message && message.type === "MAINLINE_EXPAND_PANEL" && isCollapsed) {
        isCollapsed = false;
        updateCollapsedUI();
        save();
        saveLayoutOnly();
      }
    });
  } catch (error) {
    // Ignore when chrome.runtime is not available.
  }

  widthResizer.addEventListener("pointerdown", event => {
    event.preventDefault();
    event.stopPropagation();
    widthResizer.setPointerCapture(event.pointerId);
    widthResizer.classList.add("dragging");

    const startX = event.clientX;
    const startWidth = host.getBoundingClientRect().width;

    function onMove(moveEvent) {
      const min = Math.max(220, Math.round(window.innerWidth * 0.14));
      const max = Math.max(min + 40, Math.min(720, Math.round(window.innerWidth * 0.75)));
      const nextWidth = clamp(startWidth + (startX - moveEvent.clientX), min, max);
      state.panelWidthPx = Math.round(nextWidth);
      applyPanelWidth();
      autosizeAllTodoFields();
      scheduleLayoutSave();
    }

    async function onUp() {
      widthResizer.classList.remove("dragging");
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      await save();
    }

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp, { once: true });
  });

  todayDockResizer.addEventListener("pointerdown", event => {
    event.preventDefault();
    event.stopPropagation();
    todayDockResizer.setPointerCapture(event.pointerId);
    todayDockResizer.classList.add("dragging");

    const startY = event.clientY;
    const startHeight = todayDock.getBoundingClientRect().height;

    function onMove(moveEvent) {
      const min = todayDockMinHeight();
      const max = todayDockMaxHeight();
      const nextHeight = clamp(startHeight - (moveEvent.clientY - startY), min, max);
      state.todayDockHeightPx = Math.round(nextHeight);
      applyTodayDockHeight();
      scheduleLayoutSave();
    }

    async function onUp() {
      todayDockResizer.classList.remove("dragging");
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      await save();
    }

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp, { once: true });
  });

  try {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || isApplyingRemoteState) return;

      const nextState = changes[STORAGE_KEY]?.newValue;
      const nextLayout = changes[LAYOUT_KEY]?.newValue;

      if (nextState && nextState._clientId !== CLIENT_ID) {
        applyExternalState(nextState);
      }

      if (nextLayout && nextLayout._clientId !== CLIENT_ID) {
        applyExternalLayout(nextLayout);
      }
    });
  } catch (error) {
    // Ignore when storage change listener is unavailable.
  }

  window.addEventListener("resize", () => {
    applyPanelWidth();
    applyTodayDockHeight();
  });

  load();

  setInterval(async () => {
    if (state?.mainlines?.length && state.lastRolloverKey !== todayKey()) {
      const wasFollowingCurrentDay = activeDateKey === state.lastRolloverKey;
      rolloverUnfinishedTodos();
      if (wasFollowingCurrentDay) {
        activeDateKey = todayKey();
        calendarMonthDate = parseDateKey(activeDateKey);
      }
      await save();
      render();
    }
  }, 60 * 1000);
})();
