# Chrome Web Store Listing

## Name

Mainline - Life Tracker

## Short Description

Keep your life mainlines, daily actions, calendar, and notes visible while you browse.

## Detailed Description

Mainline is a quiet Chrome side-panel life tracker designed to help you follow up on the
important threads of your life while staying focused on today's actions.

Use Mainline to:

- Organize ongoing life areas into flexible mainline folders
- Keep today's todos within reach in Chrome's side panel
- Plan future actions through a simple calendar
- Mark birthdays, deadlines, and other special days
- Review completed actions
- Save a separate note for each day
- Create multiple profiles for work, personal life, or privacy-sensitive contexts

Mainline stores your content locally in Chrome. It does not use ads, analytics,
or external servers.

Click the Mainline toolbar icon to open Mainline in Chrome's side panel.

## Category

Productivity

## Language

English

## Single Purpose

Mainline helps users manage and follow up on personal life mainlines, daily
actions, future plans, special dates, and dated notes from a floating Chrome
side panel.

## Permission Justifications

### storage

Stores the user's mainline folders, todos, calendar items, special days, dated
notes, profiles, and layout preferences locally in Chrome.

### sidePanel

Opens Mainline in Chrome's built-in side panel when the user clicks the toolbar
icon. Mainline no longer requests broad website access.

## Privacy Declarations

- Does not sell user data
- Does not use user data for advertising
- Does not use analytics
- Does not transmit user-created content
- Stores user-created content locally in Chrome extension storage

## Assets Still Needed

- Privacy policy hosted at a public URL
- Support email
- Store screenshots are included in the publish materials folder
- Optional 440x280 small promotional tile
