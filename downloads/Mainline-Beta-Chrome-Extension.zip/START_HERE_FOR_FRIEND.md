# Mainline Demo v1 — Quick Start

Mainline is a small side-panel life tracker for Chrome. It helps you keep a few important life threads within reach while you browse, such as work, movement, and family time.

## Install

1. Unzip the downloaded file.
2. Open Chrome.
3. Go to `chrome://extensions`.
4. Turn on **Developer mode** in the top-right corner.
5. Click **Load unpacked**.
6. Select the unzipped folder named `Mainline-Life-Tracker-Demo-v1-Stable`.
7. Pin the Mainline icon in the Chrome toolbar.
8. Click the Mainline icon to open Chrome's side panel.
9. Use Mainline from the side panel.

Mainline opens from the Chrome toolbar and stores your content locally.

## What You Will See

The demo starts with three example folders:

- **ML Projects** — Review the ranking model PR
- **Hiking** — Choose one Tiger Mountain trail
- **Family Time** — Text Mom about Sunday dinner

These are just examples. You can rename them and replace the todos with your own life threads.

## How to Use

- Click a folder name to open it.
- Click **Edit title** to rename a folder.
- Click **Add action** under the date to add a todo inside a folder.
- Click **Add quick action** under **Today** to add a quick todo.
- Click a todo text or row to edit it. Double-click selects the text.
- If a todo is checked, uncheck it first before editing.
- Click the checkbox to complete a todo.
- Move your mouse near the right side of a row. When `×` appears, click it to delete.
- Click **Calendar** at the bottom to plan a future action or set a deadline.
- Use **Todo** in Calendar for future actions. Use **Label** for special dates, such as birthdays, events, or custom reminders.
- In Calendar, click a day to add an action there. Double-click a day to view that day's main list.
- Existing Calendar todos and labels can be edited directly in the selected day list.
- Use **Deadline optional** only when an action has a real cutoff.
- Add a Calendar label for reminders that are not todos, such as birthdays or events.
- Use the profile selector under the logo to switch between identities, such as work and home.
- Text fields use browser spellcheck. Right-click a misspelled word to choose a suggestion.
- Click **Note** at the bottom to open a free note panel. Click outside to save and close it.
- Close Chrome's side panel when you do not need Mainline open.

## Please Test

1. Open each folder.
2. Add one new todo with **Add action**.
3. Click a todo and edit it.
4. Check a todo.
5. Uncheck it and edit it again.
6. Add a quick todo under Today.
7. Open Calendar and add one future action with a deadline.
8. Delete one todo with the right-side `×`.
9. Close and reopen the side panel.
10. Open Note, type something, and click outside to save.

## Feedback Questions

1. Was Mainline easy to understand?
2. Was adding and editing todos intuitive?
3. Did the Today section feel useful?
4. Did anything feel confusing or too hidden?
5. Would you keep this one click away while browsing?
6. What folders would you create for your own life?
