const GLOBAL_ENABLED_KEY = "mainline_global_enabled_demo_v1_stable";

function isInjectableUrl(url = "") {
  const blockedPrefixes = [
    "chrome://",
    "edge://",
    "brave://",
    "opera://",
    "vivaldi://",
    "about:",
    "chrome-extension://"
  ];

  if (!url || blockedPrefixes.some(prefix => url.startsWith(prefix))) return false;
  if (url.startsWith("https://chromewebstore.google.com/")) return false;
  if (url.startsWith("https://chrome.google.com/webstore")) return false;

  return /^(https?:|file:)/.test(url);
}

async function getEnabled() {
  const result = await chrome.storage.local.get(GLOBAL_ENABLED_KEY);
  return Boolean(result[GLOBAL_ENABLED_KEY]);
}

async function setEnabled(enabled) {
  await chrome.storage.local.set({ [GLOBAL_ENABLED_KEY]: Boolean(enabled) });
}

async function injectIntoTab(tab) {
  if (!tab || !tab.id || !isInjectableUrl(tab.url)) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: false },
      files: ["mainline-floating.js"]
    });
  } catch (error) {
    console.log("Mainline injection skipped:", tab.url, error?.message || error);
  }
}

async function removeFromTab(tab) {
  if (!tab || !tab.id || !isInjectableUrl(tab.url)) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: false },
      func: () => {
        document.getElementById("mainline-floating-tracker-host")?.remove();
      }
    });
  } catch (error) {
    console.log("Mainline remove skipped:", tab.url, error?.message || error);
  }
}

async function injectIntoAllNormalTabs() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) await injectIntoTab(tab);
}

async function removeFromAllNormalTabs() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) await removeFromTab(tab);
}

async function expandInTab(tab) {
  if (!tab || !tab.id || !isInjectableUrl(tab.url)) return;

  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "MAINLINE_EXPAND_PANEL" });
      return;
    } catch {
      if (attempt === 0) await new Promise(resolve => setTimeout(resolve, 160));
    }
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  const enabled = await getEnabled();
  if (enabled) await injectIntoAllNormalTabs();
});

chrome.runtime.onStartup.addListener(async () => {
  // No badge shown. State is preserved silently.
  await getEnabled();
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!(await getEnabled())) {
    await setEnabled(true);
    await injectIntoAllNormalTabs();
  }

  await injectIntoTab(tab);
  await expandInTab(tab);
});

// When Mainline is ON, future page loads keep the panel open.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!(await getEnabled())) return;
  await injectIntoTab(tab);
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  if (!(await getEnabled())) return;
  try {
    const tab = await chrome.tabs.get(tabId);
    await injectIntoTab(tab);
  } catch {
    // Ignore if the tab is gone.
  }
});
